//
//  Register.swift
//  Kaidee
//
//  Created by Vicky on 4/6/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


class Register: UIViewController{
    //...
    
    
    
    
   
    
    @IBOutlet weak var PhoneNo: UITextField!
   
    @IBOutlet weak var OTP: UITextField!
  
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var hideLabel: UILabel!
    
    
    
    var arrRes = [[String:AnyObject]]()
    var phoneNum=""
    
    
    @IBAction func requestOTP(_ sender: UIButton) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view.
    }
  
    
    @IBAction func submit(_ sender: UIButton) {
        if (PhoneNo.text?.characters.count)! < 10 || (PhoneNo.text?.characters.count)!>10 || (password.text?.characters.count)! == 0 {
            
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "please put 10 digits phone# & valid password", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
            
        }
        else{
            let phoneNum = String(PhoneNo.text!)
            let pass = String(password.text!)
            _ = String(OTP.text!)
            
            
            print(phoneNum ?? "0")
            let url = "http://10.202.190.193:8000/db/register/"
            
            let dic = ["phoneNum": phoneNum,"password":pass]
            NSLog("%@", dic);
            do {
                (Alamofire.request(url, method: .post, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                        self.performSegue(withIdentifier:"next", sender: sender)
                    }else{
                        print("NOOOOOOO")
                        self.hideLabel.text="Invalid phone number"
                    }
                    
                })
                
                
                
                
            }
        }

    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        phoneNum = String(PhoneNo.text!)
        if segue.identifier == "next" {
            
            if let destinationPhone = segue.destination as? Preference {
                destinationPhone.phoneNum1 = phoneNum
            }
        }
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
   

    
}
