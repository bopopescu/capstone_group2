//
//  ProductRecommendation.swift
//  Kaidee
//
//  Created by Vicky on 4/8/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage
import SwiftyJSON


class ProductRecommendation:UIViewController,UISearchBarDelegate,UITextFieldDelegate{
    

   
    @IBOutlet weak var search1: UISearchBar!
    
    @IBOutlet weak var filter: UIButton!
    @IBOutlet weak var but1: UIButton!
    @IBOutlet weak var but3: UIButton!
    
    @IBOutlet weak var but8: UIButton!
    @IBOutlet weak var but2: UIButton!
    @IBOutlet weak var but6: UIButton!
    @IBOutlet weak var but4: UIButton!
    @IBOutlet weak var but7: UIButton!
    @IBOutlet weak var but5: UIButton!
    var userID1 : Int!
    var hashTag = ""
    var catID : Int!
    var likeFirstHand : Bool!
    var prodIDList = [Int]()
    var prodIDImage : Array<UIImage>!
    var checkFin=false
    var productTosend : Int!
    var okToGo=false
    
    
    var arrRes = [[String:AnyObject]]()
    var arrRes2 = [[String:AnyObject]]()
    var check=false
    
    @IBOutlet weak var imageV1: UIImageView!
    @IBOutlet weak var imageV2: UIImageView!
    
    @IBOutlet weak var imageV3: UIImageView!
   
    @IBOutlet weak var imageV4: UIImageView!
   
    @IBOutlet weak var imageV5: UIImageView!
    @IBOutlet weak var imageV6: UIImageView!
    @IBOutlet weak var imageV7: UIImageView!
    @IBOutlet weak var imageV8: UIImageView!
    @IBOutlet weak var Label1: UILabel!
    
    
    var countP : Int!
  
    @IBAction func butt1(_ sender: UIButton) {
        self.productTosend=self.prodIDList[0]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    @IBAction func butt2(_ sender: UIButton) {
        self.productTosend=self.prodIDList[1]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    @IBAction func butt3(_ sender: UIButton) {
        self.productTosend=self.prodIDList[2]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    @IBAction func butt4(_ sender: UIButton) {
        self.productTosend=self.prodIDList[3]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    @IBAction func butt5(_ sender: UIButton) {
        self.productTosend=self.prodIDList[4]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    
    @IBAction func butt6(_ sender: UIButton) {
        self.productTosend=self.prodIDList[5]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    
    @IBAction func butt7(_ sender: UIButton) {
        self.productTosend=self.prodIDList[6]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    @IBAction func butt8(_ sender: UIButton) {
        self.productTosend=self.prodIDList[7]
        self.performSegue(withIdentifier: "goToOneProduct",sender:sender)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        search1.delegate=self
    }
    override func viewDidAppear(_ animated: Bool) {
        self.menuBtn.selectedSegmentIndex=0
        self.but1.isEnabled=false
        self.but2.isEnabled=false
        self.but3.isEnabled=false
       self.but4.isEnabled=false
        self.but5.isEnabled=false
        self.but6.isEnabled=false
        self.but7.isEnabled=false
        self.but8.isEnabled=false
       countP=0
        print(userID1)
        if (self.userID1>0){
        let url = "http://10.202.190.193:8000/db/checkforpref/"
        let dic1 = ["userID": userID1] as [String : Int]
        
        Alamofire.request(url,method: .post, parameters: dic1, encoding: JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                NSLog("%@", url);
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["PREF"].arrayObject {
                    
                    self.arrRes = resData as! [[String:AnyObject]]
                    
                    NSLog("%@", resData);
                }
                if self.arrRes.count > 0 {
                    
                         self.catID = self.arrRes[0]["catID"] as! Int
                         self.likeFirstHand = self.arrRes[0]["likeFirstHand"] as! Bool
                         self.getProdID(catID: self.catID, likeFirstHand: self.likeFirstHand)
                    
                    }
            }
            }
            
        
    }
        else
        {
            var countX1=0
            var Array11 : Array<Int>!
            var temp1=0
            let url21 = "http://10.202.190.193:8000/db/getallprod/"
        
            Alamofire.request(url21).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url21);
                    
                    let swiftyJsonVar21 = JSON(responseData.result.value!)
                    if let resData21 = swiftyJsonVar21["ProdAll"].arrayObject {
                        for x in resData21{
                            Array11=x as! Array<Int>
                            while(countX1<8 && countX1<(x as! Array<Int>).count){
                                temp1=Array11[countX1] as Int!
                                self.prodIDList.append(temp1)
                                countX1=countX1+1
                            }
                            self.appendImage(prodIDList: self.prodIDList)
                            print(self.prodIDList)
                        }
                    }
                }
            }
        }
        
      
        
    }
    

    
    
    


    func imageWithImage(image:UIImage, scaledToSize newSize:CGSize) -> UIImage{
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0);
        image.draw(in: CGRect(origin: CGPoint.zero, size: CGSize(width: newSize.width, height: newSize.height)))
        let newImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    func getButtImage(productID:Int){
        
        
        print("getPic")
        
        let dict = ["productID":productID] as [String : Int]
        Alamofire.request("http://10.202.190.193:8000/db/getpicbyproductid/", method: .post,parameters:dict, encoding: JSONEncoding.default,headers:nil).responseImage { response in
            guard let image = response.result.value else {
                NSLog("%@", "error");
                return
            }
            

            if productID>0 {
                if(productID==self.prodIDList[0]){
                    print("putimage0")
                    print(self.prodIDList[0])
                    self.imageV1.image=image
                    self.but1.isEnabled=true
                   
                }else if(productID==self.prodIDList[1]){
                    print("putimage1")
                    print(self.prodIDList[1])
                    self.imageV2.image=image
                     self.but2.isEnabled=true
                   
                }else if(productID==self.prodIDList[2]){
                    print("putimage2")
                    print(self.prodIDList[2])
                    self.imageV3.image=image
                     self.but3.isEnabled=true
                    
                }else if(productID==self.prodIDList[3]){
                    print("putimage3")
                    print(self.prodIDList[3])
                    self.imageV4.image=image
                     self.but4.isEnabled=true
                   
                }else if(productID==self.prodIDList[4]){
                    print("putimage4")
                    print(self.prodIDList[4])
                    self.imageV5.image=image
                     self.but5.isEnabled=true
                    
                }else if(productID==self.prodIDList[5]){
                    print("putimage5")
                    print(self.prodIDList[5])
                    self.imageV6.image=image
                     self.but6.isEnabled=true
                   
                }else if(productID==self.prodIDList[6]){
                    print("putimage6")
                    print(self.prodIDList[6])
                    self.imageV7.image=image
                     self.but7.isEnabled=true
                    
                }else if(productID==self.prodIDList[7]){
                    print("putimage7")
                    print(self.prodIDList[7])
                    self.imageV8.image=image
                     self.but8.isEnabled=true
                   
                }

            }
            
            
            // Do stuff with your image
        }
        
    
    }

    func getProdID(catID:Int,likeFirstHand:Bool){
        var countX=0
        var Array1 : Array<Int>!
        var temp=0
        let url2 = "http://10.202.190.193:8000/db/getprodrec/"
        let dic2 = ["catID": catID, "likeFirstHand":likeFirstHand] as [String : Any]
        
        Alamofire.request(url2,method: .post, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                NSLog("%@", url2);
            
                let swiftyJsonVar2 = JSON(responseData.result.value!)
                if let resData2 = swiftyJsonVar2["ProdRec"].arrayObject {
                    for x in resData2{
                        Array1=x as! Array<Int>
                        while(countX<8 && countX<(x as! Array<Int>).count){
                            temp=Array1[countX] as Int!
                            self.prodIDList.append(temp)
                            print(self.prodIDList[countX])
                            countX=countX+1
                        }
                         self.appendImage(prodIDList: self.prodIDList)
                       
                    }
        }
    }
        }
}
        

        
    
    func appendImage(prodIDList : Array<Int>){
        print("APPENDIMAGE")
        for i in self.prodIDList{
            self.getButtImage(productID:i)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if(searchBar==search1){
            print(search1.text!)
            self.hashTag=search1.text!
           
            
        }
    }
   
    
      @IBOutlet weak var menuBtn: UISegmentedControl!
    @IBAction func menu(_ sender: Any) {
        if (menuBtn.selectedSegmentIndex==0){
            return
        }else if (menuBtn.selectedSegmentIndex==1){
            self.performSegue(withIdentifier: "toProfile", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==2){
            self.performSegue(withIdentifier: "toWish", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==3){

            let url4 = "http://10.202.190.193:8000/db/checkifseller/"
            let dic4 = ["userID": self.userID1] as [String : Int]
            Alamofire.request(url4, method: .post, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="yes"){
                              self.performSegue(withIdentifier: "toSell", sender: sender)
                }
                else{
                    print("NOT SELLER")
                    let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "please put seller info in your profile", style: .default, handler: nil)
                    alertController.addAction(OKAction)
                    self.present(alertController, animated: true, completion: nil)
                   
                    
                }
                
            }
        }
        
    }
    
    @IBAction func search(_ sender: UIButton) {
        self.performSegue(withIdentifier: "toSearch", sender: sender)
        
    }
    
    @IBAction func filter(_ sender: UIButton) {
        self.performSegue(withIdentifier: "toFilter", sender: sender)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("prepare")
        if(segue.identifier=="toHome"){
            
            
        }else if(segue.identifier=="toProfile"){
            if(userID1==0){
                self.performSegue(withIdentifier: "pleaseLogIn", sender: sender)
            }else{
                if let destPage=segue.destination as? profile {
                    destPage.uID = userID1
                    
                }
            }
            
        }
        else if(segue.identifier=="toWish"){
            if(userID1==0){
                self.performSegue(withIdentifier: "pleaseLogIn", sender: sender)
            }else{
                if let destPage=segue.destination as? wishlist {
                    destPage.userID = userID1
                    
                }
            }
            
        }
        else if(segue.identifier=="toSell"){
            if(userID1==0){
                self.performSegue(withIdentifier: "pleaseLogIn", sender: sender)
            }
           
            else{
                let url3 = "http://10.202.190.193:8000/db/checkifseller/"
                let dic3 = ["userID": self.userID1] as [String : Int]
                Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="yes"){
                        self.okToGo=true
                                        if let destPage=segue.destination as? sell {
                                            destPage.userID = self.userID1
                        }
                    }
                    
                    
                }

                
                
            }
            
            
        }else if(segue.identifier=="toFilter"){
            if let destPage=segue.destination as? Filter {
                destPage.userID = userID1
            
            }
        }else if(segue.identifier=="toSearch"){
            
            if let destPage=segue.destination as? FilteredProduct {
                destPage.fromWhere = "search"
                destPage.userID = userID1
                print(destPage.fromWhere)
                print(destPage.userID)
                destPage.hashTag=self.hashTag
                print(destPage.hashTag)
                
                
                
              }
        }else if(segue.identifier=="goToOneProduct"){
            
            if let destPage=segue.destination as? ProductName {
                destPage.userID=self.userID1
                destPage.productID=self.productTosend
                
            }
        }
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
