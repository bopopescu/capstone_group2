//
//  FilteredProduct.swift
//  Kaidee
//
//  Created by Vicky on 4/13/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage
import SwiftyJSON
class FilteredProduct: UIViewController {
    var catID : Int!
    var subcatID : Int!
    var minP : Int!
    var maxP : Int!
    var fromWhere : String!
    var userID : Int!
    var hashTag : String!
    var prodIDList  = [Int]()
    var arrRes = [Int]()
    var arrRes1 = [Int]()
    var len=0
    var countH=0
    var productToSend : Int!
    
    @IBOutlet weak var labelHead: UILabel!
    

    @IBOutlet weak var scrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
       

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
    
        if(self.fromWhere=="filter"){
            print(self.catID)
            print(self.subcatID)
            print(self.minP)
            print(self.maxP)
            print(userID)
            var countA=0
            let url = "http://10.202.190.193:8000/db/getfilteredproduct/"
            let dic = ["catID":self.catID,"subcatID":self.subcatID,"minP":self.minP,"maxP":self.maxP]
            
            Alamofire.request(url,method: .post, parameters: dic,encoding : JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["ProdFilterID"].arrayObject {
                        self.arrRes = resData[0] as! [Int]
                        if self.arrRes.count>0{
                            while(countA<self.arrRes.count){
                                print(self.arrRes[countA])
                                self.prodIDList.append(self.arrRes[countA])
                                countA=countA+1
                            }
                        }else{
                            self.labelHead.text="No product matches"
                        }
                    }
                }
                 self.appendImage(prodIDList: self.prodIDList)
                 self.scrollView.contentSize = CGSize(width: 375, height: (self.arrRes.count+3)*350)
            }
           
            
        }else if(self.fromWhere=="search"){
            print(self.hashTag)
            print(self.userID)
            var countB=0
            let url1 = "http://10.202.190.193:8000/db/getidbyhashtag/"
            let dic1 = ["hashtag":self.hashTag!]
            print("hashTag is "+self.hashTag)
            
            Alamofire.request(url1,method: .post, parameters: dic1,encoding : JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    print(responseData.result.value)
                    NSLog("%@", url1);
                    
                    let swiftyJsonVar1 = JSON(responseData.result.value!)
                    if let resData1 = swiftyJsonVar1["ProdHashtag"].arrayObject {
                        self.arrRes1 = resData1[0] as! [Int]
                        if self.arrRes1.count>0{
                            while(countB<self.arrRes1.count){
                                print(self.arrRes1[countB])
                                self.prodIDList.append(self.arrRes1[countB])
                                countB=countB+1
                            }
                        }else{
                            self.labelHead.text="No product matches"
                        }
                    }
                }
                self.appendImage(prodIDList: self.prodIDList)
                self.scrollView.contentSize = CGSize(width: 375, height: (self.arrRes.count+3)*350)
            }
        }
   
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func pressed(_ sender: UIButton) {
        let btnsendtag: UIButton = sender
        print(btnsendtag.tag)
        self.productToSend=btnsendtag.tag
        print(btnsendtag.tag)
        self.performSegue(withIdentifier: "goToProductName", sender: sender)
        
    }
    
    func appendImage(prodIDList : Array<Int>){
        for i in self.prodIDList{
            self.getButtImage(productID:i)
        }
    }
    
    func getButtImage(productID:Int){
        
        
        print("getPic")
        let dict = ["productID":productID] as [String : Int]
        Alamofire.request("http://10.202.190.193:8000/db/getpicbyproductid/", method: .post,parameters:dict, encoding: JSONEncoding.default,headers:nil).responseImage { response in
            guard let image = response.result.value else {
                NSLog("%@", "error");
                return
            }
            let button = UIButton(frame: CGRect(x: 10 , y: 0+(self.countH*340), width:340, height: 340))
            button.addTarget(self, action: #selector(self.pressed(_:)), for: .touchUpInside)
            button.tag=productID
            print(productID)
            let imV = UIImageView(frame: CGRect(x: 10 , y: 0+(self.countH*340), width:340, height: 340))
            imV.image=image
            self.countH=self.countH+1
            self.scrollView.addSubview(button)
            self.scrollView.addSubview(imV)
            

        }
        
        
    }
    
    @IBAction func backToHome(_ sender: UIButton) {
        self.performSegue(withIdentifier:"backToHome",sender:sender)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier=="goToProductName"){
        if let destPage=segue.destination as? ProductName {
            destPage.userID=self.userID
            destPage.productID=self.productToSend
            
            
        }
        }else if(segue.identifier=="backToHome"){
            if let destPage=segue.destination as? ProductRecommendation{
                destPage.userID1=self.userID
            }
        }
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
