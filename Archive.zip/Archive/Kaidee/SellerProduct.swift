//
//  SellerProduct.swift
//  Kaidee
//
//  Created by supidsara thantanaporn on 4/6/17.
//  Copyright © 2017 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage

class SellerProduct: UIViewController {
    var sellerID : Int!
    var phone = ""
    var userID : Int!
    var countH=0
    var x = 0
    var check = true
    var productToSend :Int!
    var id=[Int]()
    var arrRes = [[String:AnyObject]]()

    
    @IBOutlet weak var telLabel: UILabel!
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBAction func infoproduct2(_ sender: UISegmentedControl) { self.performSegue(withIdentifier: "tosellerinfo", sender: sender)
        
    }
   
    @IBOutlet weak var menuBtn: UISegmentedControl!
    @IBAction func menu(_ sender: Any) {
        if (menuBtn.selectedSegmentIndex==0){
            self.performSegue(withIdentifier: "toHome", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==1){
            if(self.userID==0){
                self.performSegue(withIdentifier: "toLogIn", sender:sender)
            }else{
                self.performSegue(withIdentifier: "toProfile", sender: sender)
            }
        }else if (menuBtn.selectedSegmentIndex==2){
            if(self.userID==0){
                self.performSegue(withIdentifier: "toLogIn", sender:sender)
            }else{
                self.performSegue(withIdentifier: "toWish", sender: sender)
            }
        }else if (menuBtn.selectedSegmentIndex==3){
            let url4 = "http://10.202.190.193:8000/db/checkifseller/"
            let dic4 = ["userID": self.userID] as [String : Int]
            Alamofire.request(url4, method: .post, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="yes"){
                    self.performSegue(withIdentifier: "toSell", sender: sender)
                }
                else{
                    print("NOT SELLER")
                    let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "please put seller info in your profile", style: .default, handler: nil)
                    alertController.addAction(OKAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                    
                }
                
            }
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "tosellerinfo") {
            let destinationVC = segue.destination as! sellerProfile
            destinationVC.sellerID=sellerID
            destinationVC.userID=self.userID
            destinationVC.phone=self.phone
            
        }else if(segue.identifier=="toHome"){
            if let destPage=segue.destination as? ProductRecommendation {
                destPage.userID1=self.userID
            }
            
        }else if(segue.identifier=="toWish"){
            if let destPage=segue.destination as? wishlist {
                destPage.userID=self.userID
            }
            
        }else if(segue.identifier=="toProfile"){
            if let destPage=segue.destination as? profile {
                destPage.uID=self.userID
            }
            
        }else if(segue.identifier=="ProductNameVC"){
            if let destPage=segue.destination as? ProductName {
                destPage.userID=self.userID
                destPage.productID=self.productToSend
            }
            
        }
        else if(segue.identifier=="toSell"){
            if(userID==0){
                self.performSegue(withIdentifier: "toLogIn", sender: sender)
                return
            }
                
            else{
                let url3 = "http://10.202.190.193:8000/db/checkifseller/"
                let dic3 = ["userID": self.userID] as [String : Int]
                Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="yes"){
                        
                        if let destPage=segue.destination as? sell {
                            destPage.userID = self.userID
                        }
                    }
                    
                    
                }
                
                
                
            }
            
            
        }
    }
    @IBOutlet weak var productPic1: UIButton!

    @IBOutlet weak var SellerPic: UIImageView!
    
    @IBOutlet weak var SellerName: UILabel!
    @IBOutlet weak var SellerAddress: UILabel!
    
    @IBOutlet weak var SellerTel: UILabel!
    
    @IBAction func InfoProduct(_ sender: Any) {
    }
   
    @IBOutlet weak var ScrollProduct: UIView!
    @IBAction func BottomBar(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        telLabel!.text = self.phone
        var a = String(sellerID)
        SellerName.text = "Seller ID:"+String(sellerID)
        let url = "http://10.202.190.193:8000/db/selid/"+a
        getID(url:url)

        // Do any additional setup after loading the view.
    }
    
    func getID(url: String){
        Alamofire.request(url).responseJSON { (responseData) -> Void in
            print(responseData)
            if((responseData.result.value) != nil) {
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["id"].arrayObject {
                    self.id=resData[0] as! [Int]
                }
                if(self.id.count>0){
                    for k in self.id{
                        print(k)
                        let url2 = "http://10.202.190.193:8000/db/sellerproduct/"+String(self.sellerID)+"/"+String(k)+"/"
                        self.getPic(url: url2,proid:k)
                        
                    }
                }
            }else{
                print("null")
            }
        }
        
        print(self.id)

        
    }
    
    func getPic(url: String,proid: Int){
        print("getPic")
        print(url)
        Alamofire.request(url, method: .post,parameters:nil, encoding: JSONEncoding.default,headers:nil).responseImage { response in
            guard let image = response.result.value else {
                NSLog("%@", "not active");
                if(self.check){
                    self.check = false
                }else{
                    self.check = true
                }
                return
            }
            let button = UIButton(frame: CGRect(x: 137 , y: 0+(self.countH*110), width:100, height: 100))
            button.addTarget(self, action: #selector(self.pressed(_:)), for: .touchUpInside)
            let imV = UIImageView(frame: CGRect(x: 137 , y: 0+(self.countH*110), width:100, height: 100))
            self.scrollView.contentSize = CGSize(width: 375, height: self.countH*120)
            button.tag = proid
            print(imV.frame)
            imV.image=image
            print("set")
            self.countH=self.countH+1
            self.scrollView.addSubview(button)
            self.scrollView.addSubview(imV)
        }
    }
    
    @IBAction func pressed(_ sender: UIButton) {
        let btnsendtag: UIButton = sender
        print(btnsendtag.tag)
        self.productToSend=btnsendtag.tag
        print(btnsendtag.tag)
        self.performSegue(withIdentifier: "ProductNameVC", sender: sender)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
}
