 //
//  browseProduct.swift
//  try
//
//  Created by Admin on 4/9/2560 BE.
//  Copyright © 2560 Admin. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage

class browseProduct: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate {
    
    @IBOutlet weak var fee: UITextField!
    
    @IBOutlet weak var status: UISegmentedControl!
    
     @IBOutlet weak var hashtag: UITextField!
    @IBAction func onCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        
    }
    
    @IBOutlet weak var productImage: UIImageView!
    var sendImage: UIImage!
    var userid: Int!
    var productid : Int!
    var localPath:URL!
    var dic:[String:String]!
    var catid: Int!
    var subcatid: Int!
    var count=0
    var checkid = false

    @IBOutlet weak var tag: UITextField!
    @IBOutlet weak var productID: UILabel!
    @IBOutlet weak var prodDes: UITextView!

    @IBOutlet weak var price: UITextField!
    @IBOutlet weak var hash2: UIButton!
    @IBOutlet weak var hash1: UIButton!
    @IBOutlet weak var hash3: UIButton!
    @IBOutlet weak var hash4: UIButton!
    @IBOutlet weak var textCat: UITextField!
    
    @IBOutlet weak var dropCat: UIPickerView!
    
    @IBOutlet weak var textSubCat: UITextField!
    
    @IBOutlet weak var dropSubCat: UIPickerView!
    var cat=["มือถือ","คอมพิวเตอร์","เครื่องดนตรี","กีฬา","จักรยาน","แม่และเด็ก","กระเป๋า","นาฬิกา","รองเท้า","เสื้อผ้าและเครื่องแต่งกาย","สุขภาพและความงาม","บ้านและสวน","พระเครื่อง","ของสะสม","กล้อง","เครื่องใช้ไฟฟ้า","เกมส๋","สัตว์เลี้ยง","อสังหาริมทรัพย์","รถมือสอง","อะไหล่รถ","มอเตอร์ไซค์","งานอดิเรก","ธุรกิจ","บริการ","ท่องเที่ยว","การศึกษา","แบ่งปัน"]
    var subCat:[String] = []

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fee.delegate=self
        hashtag.delegate=self
        
        prodDes.layer.borderWidth=0.5
        prodDes.layer.borderColor=UIColor.black.cgColor
        prodDes.layer.cornerRadius=5
        hash1.layer.cornerRadius=5
        hash2.layer.cornerRadius=5
        hash3.layer.cornerRadius=5
        hash4.layer.cornerRadius=5
        sendImage = imageWithImage(sourceImage:sendImage,scaledToWidth:300)
        productImage.image = sendImage
        
        print(userid)
        print("loaded")
        tag.delegate=self
        price.delegate=self
        textCat.delegate=self
        textSubCat.delegate=self


        // Do any additional setup after loading the view.
    }
    
    func imageWithImage(sourceImage:UIImage,scaledToWidth: CGFloat) -> UIImage{
        let oldWidth = sourceImage.size.width
        let scaleFactor = scaledToWidth/oldWidth
        
        let newHeight = sourceImage.size.height*scaleFactor
        let newWidth = oldWidth*scaleFactor
        
        UIGraphicsBeginImageContext(CGSize(width:newWidth, height:newHeight))
        sourceImage.draw(in: CGRect(x:0,y:0,width:newWidth,height:newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitSell(_ sender: Any) {
        addproduct()
        let alert = UIAlertController(title: "Congratulations!", message: "Successfully posted the item! Thank you for joining us!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler:
            {
                [unowned self] (action) -> Void in
                
                self.performSegue(withIdentifier: "toHome", sender: sender)
        }))
        
        self.present(alert, animated: true, completion: nil)

        
        
    }
    
    func addproduct(){
        if((prodDes.text?.characters.count)!<20){
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "please put description at least 2 sentences", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }
        else if(Int(price.text!)==nil){
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "Invalid price", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }
        else if catid == nil || subcatid == nil{
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "please select subcategory and category", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }
        else if (Int(fee.text!)==nil){
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "Invalid delivery fee", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }else{
            dic = ["description":prodDes.text!,"price":price.text!,"cat": String(catid),"subcat":String(subcatid),"status":String(status.selectedSegmentIndex),"hashtag":tag.text!,"fee":fee.text!]
            
            let imageName = "temp.jpg"
            let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let imagePath = documentsDirectoryURL.appendingPathComponent(imageName)
            
            // Set static name, so everytime image is cloned, it will be named "temp", thus rewrite the last "temp" image.
            // *Don't worry it won't be shown in Photos app.
            
            
            // Encode this image into JPEG. *You can add conditional based on filetype, to encode into JPEG or PNG
            if let data = UIImageJPEGRepresentation(sendImage, 80) {
                // Save cloned image into document directory
                do{
                    try(data.write(to: imagePath))
                    
                }catch{
                    print(Error.self)
                }
                
                localPath = imagePath
                let url = "http://10.202.190.193:8000/db/addproduct/"+String(userid)+"/"
                print(url)
                
                Alamofire.upload(multipartFormData: { MultipartFormData in
                    // get file path URL
                    let filePath = self.localPath
                    // add file as Request Body with fieldname "upload"
                    MultipartFormData.append(filePath!, withName: "upload")
                    
                    //     MultipartFormData.append("Alamofire".data(using:String.Encoding.utf8, allowLossyConversion: false)!,withName:"test")
                    let dict = self.dic as! [String:String]
                    
                    
                    for(key,value) in dict{
                        if JSONSerialization.isValidJSONObject(value) {
                            let array = value as! [String]
                            
                            for string in array {
                                if let stringData = string.data(using: .utf8) {
                                    MultipartFormData.append(stringData, withName: key+"[]")
                                }
                            }
                            
                        } else {
                            MultipartFormData.append(String(describing: value).data(using: .utf8)!, withName: key)
                        }
                    }
                    
                    
                }, to: url, method: .post, headers: nil, encodingCompletion: {
                    encodingResult in
                    print(encodingResult)
                    switch encodingResult {
                    case .success(let upload, _, _):
                        print("success!!!!!")
                        upload.response { [weak self] response in
                            guard let strongSelf = self else {
                                return
                            }
                            print("response")
                            let d=JSON(response.data)
                            print(d)
                            var k = d["id"].int!
                            print(k)
                            self!.productid = k
                            print("self!.productid")
                            print(self!.productid)
                            
                        }
                    case .failure(let error):
                        print(error)
                    }
                })
                
                
                
            }
        }
        
        
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return  1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        var countRow: Int = cat.count
        if pickerView == dropSubCat{
            countRow = self.subCat.count
        }
        return countRow
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView==dropCat{
            return cat[row]
        }else{
            return subCat[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView==dropCat{
            self.catid = row
            self.textCat.text=String(self.cat[row])!
            self.dropCat.isHidden=true
            if row==0 {
                subCat=["android","iOS"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
                
            }else if row==1{
                subCat=["Labtop","PC","Tablet"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==2{
                subCat=["portable","non-portable"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==3{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==4{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==5{
                subCat=["อุปกรณ์","หนังสือ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==6{
                subCat=["กระเป๋าถือ","กระเป๋าสตางค์","กระเป๋าขนาดใหญ่"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==7{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==8{
                subCat=["แตะ","หุ้มส้น","กีฬา","ส้นสูง"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==9{
                subCat=["เสื้อ","กางเกง","กระโปรง","เดรส","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==10{
                subCat=["voucher","ผลิตภัณฑ์"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==11{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==12{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==13{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==14{
                subCat=["film","digital"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==15{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==16{
                subCat=["อุปกรณ์","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==17{
                subCat=["บก","น้ำ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==18{
                subCat=["บ้าน","คอนโด","ที่ดิน"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==19{
                subCat=["เก๋ง","กระบะ","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==20{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==21{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==22{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==23{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==24{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==25{
                subCat=["ที่พัก","การเดินทาง","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==26{
                subCat=["คอร์ส","อุปกรณ์"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }

        
        }else if pickerView==dropSubCat{
             self.subcatid = row
            self.textSubCat.text=String(self.subCat[row])!
            self.dropSubCat.isHidden=true
        }
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField==self.textCat{
            dropCat.isHidden=false
            textSubCat.text=""
        }else if textField==self.textSubCat{
            dropSubCat.isHidden=false
        }
    }
//    func textFieldDidEndEditing(_ textField: UITextField) {
//        if textField==self.textCat{
//            dropCat.isHidden=true
//        }else if textField==self.textSubCat{
//            dropSubCat.isHidden=true
//        }
//    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier=="toHome"){
            if let destPage=segue.destination as? ProductName {
                destPage.userID=self.userid
                destPage.productID = self.productid
                print("self.productid")
                print(self.productid)
            }
            
        }
        
        
    }
   

    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
