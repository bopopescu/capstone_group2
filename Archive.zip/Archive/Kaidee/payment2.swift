//
//  payment2.swift
//  Kaidee
//
//  Created by supidsara thantanaporn on 4/6/17.
//  Copyright © 2017 Group2. All rights reserved.
//

import UIKit

class payment2: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate  {
    var importImage: UIImage!
    var bankname: String!
    var strDate: String!
    var date: Date!
    var bankid: Int!
    var amount:Int!
    var uid:Int!
    var pid:Int!

    @IBOutlet weak var billImage: UIImageView!
    @IBAction func back1(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func upload(_ sender: Any) {
        let image = UIImagePickerController()
        image.delegate=self
        
        
        let refreshAlert = UIAlertController(title: "Photo Access", message: "Choose photo source", preferredStyle: .actionSheet)
        
        refreshAlert.addAction(UIAlertAction(title: "camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                image.sourceType = UIImagePickerControllerSourceType.camera
                image.allowsEditing = false
                self.present(image,animated:true)
            }else{ }
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "album", style: .default, handler: { (action: UIAlertAction) in
            image.sourceType = UIImagePickerControllerSourceType.photoLibrary
            image.allowsEditing = false
            self.present(image,animated:true,completion: nil)
        }))
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(refreshAlert,animated:true)

    }
    
    @IBAction func onCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitB(_ sender: Any) {
        self.performSegue(withIdentifier: "topayment3", sender: sender)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            billImage.image=image
            importImage=image
            print("set image")
        }else{
            //error msg
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion:nil )
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "topayment3") {
            let destinationVC = segue.destination as! payment3
            destinationVC.sendImage=importImage
            destinationVC.bankid=bankid
            destinationVC.bankname=bankname
            destinationVC.strDate=strDate
            destinationVC.date=date
            destinationVC.amount=amount
            destinationVC.productid=self.pid
            destinationVC.userid=self.uid
            print("image send")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
