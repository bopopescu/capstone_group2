//
//  Filter.swift
//  Kaidee
//
//  Created by Vicky on 4/13/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit

class Filter: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate {

    
   
    @IBOutlet weak var textCat: UITextField!
    
    @IBOutlet weak var dropCat: UIPickerView!
    
    @IBOutlet weak var textSubCat: UITextField!
    
    @IBOutlet weak var dropSubCat: UIPickerView!
    
    @IBOutlet weak var textMax: UITextField!
    @IBOutlet weak var textMin: UITextField!
    var userID :Int!
    var maxPriceInt=1000000000
    var minPriceInt=0
    var count=0
    var catID=0
    var subcatID=0
    var cat=["มือถือ","คอมพิวเตอร์","เครื่องดนตรี","กีฬา","จักรยาน","แม่และเด็ก","กระเป๋า","นาฬิกา","รองเท้า","เสื้อผ้าและเครื่องแต่งกาย","สุขภาพและความงาม","บ้านและสวน","พระเครื่อง","ของสะสม","กล้อง","เครื่องใช้ไฟฟ้า","เกมส๋","สัตว์เลี้ยง","อสังหาริมทรัพย์","รถมือสอง","อะไหล่รถ","มอเตอร์ไซค์","งานอดิเรก","ธุรกิจ","บริการ","ท่องเที่ยว","การศึกษา","แบ่งปัน"]
    var subCat:[String] = []

   
    override func viewDidLoad() {
        super.viewDidLoad()
        textCat.delegate=self
        textSubCat.delegate=self
        textMax.delegate=self
        textMin.delegate=self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return  1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        var countRow: Int = cat.count
        if pickerView == dropSubCat{
            countRow = self.subCat.count
        }
        return countRow
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView==dropCat{
            return cat[row]
        }else{
            return subCat[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView==dropCat{
            self.textCat.text=String(self.cat[row])!
            catID=row
            if row==0 {
                subCat=["android","iOS"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
                
            }else if row==1{
                subCat=["Labtop","PC","Tablet"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==2{
                subCat=["portable","non-portable"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==3{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==4{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==5{
                subCat=["อุปกรณ์","หนังสือ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==6{
                subCat=["กระเป๋าถือ","กระเป๋าสตางค์","กระเป๋าขนาดใหญ่"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==7{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==8{
                subCat=["แตะ","หุ้มส้น","กีฬา","ส้นสูง"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==9{
                subCat=["เสื้อ","กางเกง","กระโปรง","เดรส","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==10{
                subCat=["voucher","ผลิตภัณฑ์"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==11{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==12{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==13{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==14{
                subCat=["film","digital"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==15{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==16{
                subCat=["อุปกรณ์","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }else if row==17{
                subCat=["บก","น้ำ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==18{
                subCat=["บ้าน","คอนโด","ที่ดิน"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==19{
                subCat=["เก๋ง","กระบะ","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==20{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==21{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==22{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==23{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==24{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==25{
                subCat=["ที่พัก","การเดินทาง","อื่นๆ"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else if row==26{
                subCat=["คอร์ส","อุปกรณ์"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            else{
                subCat=["ทั่วไป"]
                dropSubCat.reloadAllComponents()
                if(count==0){
                    textSubCat.text=""
                    count=count+1
                }
                textSubCat.text=subCat[0]
            }
            
        }else if pickerView==dropSubCat{
            subcatID=row
            self.textSubCat.text=String(self.subCat[row])!
//            self.dropSubCat.isHidden=true
        }
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField==self.textCat{
            dropCat.isHidden=false
            textSubCat.text=""
        }else if textField==self.textSubCat{
            dropSubCat.isHidden=false
        }
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }

   
    

    @IBOutlet weak var labelShow: UILabel!
    
    @IBAction func filterProduct(_ sender: UIButton) {
        if textMin.text != "" && textMax.text != "" {
        let minPrice=textMin.text
        let maxPrice=textMax.text
        
     
        minPriceInt=Int(minPrice!)!
          maxPriceInt=Int(maxPrice!)!
        }
            if(minPriceInt<maxPriceInt && minPriceInt>=0 && maxPriceInt>0){
                self.performSegue(withIdentifier: "filterToProductList", sender: sender)
            }else{
                labelShow.text="INVALID RANGE"
            }
        
        
        
    }
   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
       
    if let destPage=segue.destination as? FilteredProduct {
        destPage.catID = self.catID
        destPage.subcatID = self.subcatID
        destPage.minP = minPriceInt
        destPage.maxP = maxPriceInt
        destPage.fromWhere = "filter"
        destPage.userID=self.userID
        
        
        }
        
    }
 
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
