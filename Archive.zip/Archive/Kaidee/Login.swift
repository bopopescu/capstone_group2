//
//  Login.swift
//  Kaidee
//
//  Created by Vicky on 4/9/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class Login: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var register: UIButton!
    
    @IBOutlet weak var phoneno: UITextField!
    
    
    
    @IBOutlet weak var password: UITextField!
    var arrRes = [[String:AnyObject]]()
    var arrRes2 = [[String:AnyObject]]()
    var boolean1 = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        phoneno.delegate=self
        password.delegate=self
        
        
        
        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func logInPressed(_ sender: UIButton) {
        boolean1 = false
        let url = "http://10.202.190.193:8000/db/log_in/"
        Alamofire.request(url).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                NSLog("%@", url);
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["users"].arrayObject {
                    
                    self.arrRes = resData as! [[String:AnyObject]]
                    
                    NSLog("%@", resData);
                }
                
                if self.arrRes.count > 0 {
                    for a in self.arrRes{
                        var dict = a
                        //                                    )
                        if((dict["phoneNumber"]as? String)==self.phoneno.text){
                            self.boolean1=true
                            if((dict["password"]as? String)==self.password.text){
                                print("LOG IN SUCCESSFUL")
                                self.performSegue(withIdentifier: "logInToHome", sender: sender)
                                
                            }else{
                                print("WRONG PASSWORD")
                                let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                                let OKAction = UIAlertAction(title: "wrong password", style: .default, handler: nil)
                                alertController.addAction(OKAction)
                                self.present(alertController, animated: true, completion: nil)
                                
                            }
                            
                        }
                    }
                }
                if(!self.boolean1){
                    print("NO ACCOUNT")
                    let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "no account", style: .default, handler: nil)
                    alertController.addAction(OKAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
        }
        
    }
   
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "logInToHome" {
            let url2 = "http://10.202.190.193:8000/db/getuid/"
            let dic2 = ["phoneNum": phoneno.text!] as [String : String]
            
            Alamofire.request(url2,method: .post, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url2);
                    
                    let swiftyJsonVar2 = JSON(responseData.result.value!)
                    if let resData2 = swiftyJsonVar2["user2"].arrayObject {
                        
                        self.arrRes2 = resData2 as! [[String:AnyObject]]
                        
                        NSLog("%@", resData2);
                    }
                    if self.arrRes2.count > 0 {
                        if let destPage=segue.destination as? ProductRecommendation {
                            let x=self.arrRes2[0]
                            destPage.userID1 = x["userID"] as!Int
                            
                            
                            
                        }
                        
                    }
                }
            }
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    //long get du
    //            Alamofire.request(url).responseJSON { (responseData) -> Void in
    //                if((responseData.result.value) != nil) {
    //
    //                    NSLog("%@", url);
    //
    //                    let swiftyJsonVar = JSON(responseData.result.value!)
    //                    if let resData = swiftyJsonVar["users"].arrayObject {
    //
    //                        self.arrRes = resData as! [[String:AnyObject]]
    //
    //                        NSLog("%@", resData);
    //                    }
    //
    //                    if self.arrRes.count > 0 {
    //                        var dict = self.arrRes[0]
    //                        print(dict["userID"] as? String)
    ////                        self.tblJSON.reloadData()
    //                    }
    //
    //                }
    //            }
    
}
