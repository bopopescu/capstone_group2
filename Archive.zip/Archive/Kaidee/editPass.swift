//
//  editPass.swift
//  Kaidee
//
//  Created by Admin on 4/6/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//
import UIKit
import Alamofire
import SwiftyJSON

class editPass: UIViewController,UITextFieldDelegate {
    var phone1 : String!
    var uID:Int!
    override func viewDidLoad() {
        super.viewDidLoad()
        print(phone1)
        
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        inputPassword.delegate=self
        checkPass.delegate=self 
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet var inputPassword: UITextField!
    
    @IBOutlet weak var checkPass: UITextField!
    
    
    @IBAction func savePass(_ sender: Any) {
        let pass = String(self.inputPassword.text!)
        if ((inputPassword.text)! == (checkPass.text)){
            
            let url = "http://10.202.190.193:8000/db/Kaidee/editPass/"
            let dic = ["password" : pass, "phoneNumber" : phone1]
            NSLog("%@", dic);
            do {
                (Alamofire.request(url, method: .put, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                    }
                    
                })
                
            }
        } else {
            
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "password not match", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
            
        }
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func onBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }

    
    
    
    /*
     
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
