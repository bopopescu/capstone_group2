//
//  comment.swift
//  try
//
//  Created by Admin on 4/8/2560 BE.
//  Copyright © 2560 Admin. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class comment: UIViewController, UITextViewDelegate {
    @IBOutlet weak var tblJSON: UITableView!
    var arrRes = [[String:AnyObject]]()
    var test: String!
    var Array = ["5","4","3","2","1"]
    var userID : Int!
  

    @IBOutlet weak var productPic: UIImageView!
    @IBOutlet weak var sellerID: UILabel!
    @IBOutlet weak var orderID: UILabel!
    @IBOutlet weak var comment: UITextView!
    @IBOutlet weak var rateSeg: UISegmentedControl!
    var productID :Int!
  


    
    
    @IBAction func skip(_ sender: Any) {
        self.performSegue(withIdentifier : "toProfile", sender: sender)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        comment.delegate=self
        
    }
    override func viewDidAppear(_ animated: Bool) {
        self.orderID.text = test
        print(test)
        print(orderID.text!)
        
        do {
            (Alamofire.request("http://10.202.190.193:8000/db/getProductIDByOrder/", method: .post, parameters:["orderID":self.orderID.text!], encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                self.productID=Int(response.result.value!)
                let dict = ["productID":self.productID] as [String : Int]
                Alamofire.request("http://10.202.190.193:8000/db/getpicbyproductid/", method: .post,parameters:dict, encoding: JSONEncoding.default,headers:nil).responseImage { response in
                    guard let image = response.result.value else {
                        NSLog("%@", "error");
                        return
                    }
                    
                    self.productPic.image=image
                }
                
            })
            
            
            
            
        }
       
        let oid = String(orderID.text!)
        // print(oid)
        let url = "http://10.202.190.193:8000/db/Kaidee/product/"
        
        let dic = ["orderID": oid]
        
        
        
        NSLog("%@", dic);
        do {
            (Alamofire.request(url, method: .post, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseJSON {(responseData) -> Void in
                //                print(response.result.value!)
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["product"].arrayObject {
                        
                        self.arrRes = resData as! [[String:AnyObject]]
                        
                        NSLog("%@", resData);
                    }
                    if self.arrRes.count > 0 {
                        for m in self.arrRes {
                            var dict = m
                            var x : (String)
                            x = (dict["sellerID"] as? String)!
                            self.sellerID.text = x
                            print(x)
                            
                        }
                    }
                }
                }
            )}
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textViewDidChange(_ textView: UITextView) {
        
    }
    func textViewDidEndEditing(_ textView: UITextView) {

            }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
   

    
    @IBAction func commentSubmit(_ sender: Any) {
        
        print(self.rateSeg.selectedSegmentIndex)
        print(self.comment.text!)
        var star = String(self.rateSeg.selectedSegmentIndex)
        
        if(star == "0") {
            star = "5"
        } else if (star == "1") {
            star = "4"
        } else if (star == "2") {
            star = "3"
        } else if (star == "3") {
            star = "2"
        } else { star = "1" }
        let comment1 = String(self.comment.text!)
        let sellerID = String(self.sellerID.text!)
        let orderID = String(self.orderID.text!)
        
        if(self.comment.text?.characters.count)! < 1{
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "Please give some comment", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)

        }else{
        
        let url = "http://10.202.190.193:8000/db/Kaidee/comment/"
        
        let dic = ["comment": comment1,"star":star, "sellerID":  sellerID, "orderID": orderID, "buyerID": self.userID] as [String : Any]
        NSLog("%@", dic);
        do {
            (Alamofire.request(url, method: .post, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="success"){
                    print("SUCCESSSSSS")
                    //                    self.performSegue(withIdentifier:"next", sender: sender)
                }else{
                    print("NOOOOOOO")
                    //                    self.hideLabel.text="Invalid phone number"
                }
                
            })
            
        }
        self.performSegue(withIdentifier: "toProfile", sender: sender)
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
        if segue.identifier == "toProfile" {
            if let destinationP = segue.destination as? profile {
        
                destinationP.uID=self.userID
            }
        }
        
        
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
////        if pickerView==Picker1{
//            return Array[row]
////    }
////        else {return Array1[row]}
//    }
//    
//        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//            return Array.count
//        }
//        
//        public func numberOfComponents(in pickerView: UIPickerView) -> Int{
//            return 1
//        }


}
