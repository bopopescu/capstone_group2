//
//  sellerProfile.swift
//  Kaidee
//
//  Created by supidsara thantanaporn on 4/6/17.
//  Copyright © 2017 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import Cosmos


class sellerProfile: UIViewController {

    var userID: Int!
    var sellerID :Int!
    var phone = ""
    var star = 0.0
    var comment = [[String:AnyObject]]()
    var com = ""
    var rating = 0.0
    var sum = 0.0
    var count = 0
    var commentlist = [String]()
    var ratinglist = [Double]()
    var cosmolist = [CosmosView]()
    var comlist = [UILabel]()
    var viewlist = [UIView]()
    var h = 0
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var avgstarview: CosmosView!
    @IBOutlet weak var rating1: CosmosView!
    @IBOutlet weak var com2: CosmosView!
    @IBOutlet weak var rating3: CosmosView!
    @IBOutlet weak var rating4: CosmosView!
    @IBOutlet weak var rating5: CosmosView!
    @IBOutlet weak var rating6: CosmosView!
    @IBOutlet weak var rating7: CosmosView!
    @IBOutlet weak var rating8: CosmosView!
    
    @IBOutlet weak var commentlistView: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view5: UIView!
    @IBOutlet weak var view6: UIView!
    @IBOutlet weak var view7: UIView!
    @IBOutlet weak var view8: UIView!

    @IBOutlet weak var comView: UILabel!
    
    @IBOutlet weak var comView2: UILabel!
    
    @IBOutlet weak var comView3: UILabel!
    @IBOutlet weak var comView4: UILabel!
    @IBOutlet weak var comView5: UILabel!
    @IBOutlet weak var comView6: UILabel!
    @IBOutlet weak var comView7: UILabel!
    @IBOutlet weak var comView8: UILabel!
    
    @IBAction func infoproduct(_ sender: Any) {
        
                self.performSegue(withIdentifier: "tosellerproduct", sender: sender)
             }
 
  
    @IBOutlet weak var SellerPic: UIImageView!
    @IBAction func InfoProduct(_ sender: Any) {
    }
    @IBOutlet weak var SellerTel: UILabel!
    @IBOutlet weak var SellerAddr: UILabel!
    @IBOutlet weak var SellerName: UILabel!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        viewlist.append(view1)
        viewlist.append(view2)
        viewlist.append(view3)
        viewlist.append(view4)
        viewlist.append(view5)
        viewlist.append(view6)
        viewlist.append(view7)
        viewlist.append(view8)
        
        for a in viewlist{
            a.isHidden = true
        }

        rating1.settings.updateOnTouch = false
        avgstarview.settings.updateOnTouch = false
        com2.settings.updateOnTouch = false
        
        self.scrollView.contentSize = CGSize(width: 343, height: 0)
        
        let url = "http://10.202.190.193:8000/db/sellerprofile/"+String(sellerID)
        getData(url: url)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getData(url: String) {
        Alamofire.request(url).responseJSON { (responseData) -> Void in
            print(responseData)
            if((responseData.result.value) != nil) {
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                //                self.sellerID = swiftyJsonVar["uid"].int!
                self.phone = swiftyJsonVar["phone"].string!
                self.star = swiftyJsonVar["star"].double!
                if let resData = swiftyJsonVar["comment"].arrayObject {
                    
                    self.comment = resData as! [[String:AnyObject]]
                    
                    print(resData)
                }
                self.scrollView.contentSize = CGSize(width: 343, height: self.comment.count*120)
                var newcount:Int!
                if self.comment.count>5{
                     self.scrollView.contentSize = CGSize(width: 343, height: 600)
                    newcount = self.comment.count-5
                    print("more than 5")
                    print(newcount)
                    while(newcount<self.comment.count){
                        var dict = self.comment[newcount]
                        self.commentlist.append(dict["comment"] as! String)
                        self.ratinglist.append(dict["rating"] as! Double)
                        newcount=newcount+1
                        var t = dict["rating"] as! Double
                        self.sum = self.sum+t
                    }
                    
                }else if (self.comment.count > 0) && (self.comment.count <= 5) {
                    for a in self.comment{
                        var dict = a
                        self.commentlist.append(dict["comment"] as! String)
                        self.ratinglist.append(dict["rating"] as! Double)
                        self.count=self.count+1
                        var t = dict["rating"] as! Double
                        self.sum = self.sum+t
                        
                    }
                }else{
                    self.commentlistView.isHidden = true
                    
                }
                self.SellerName.text = "SELLER ID : "+String(self.sellerID)
                self.SellerTel.text = "Phone No: "+self.phone
                print("tel"+String(self.phone))
                print("star"+String(self.star))
                //                self.rating1.rating = self.star
                //                self.comView.text = self.com
                print("comment"+String(self.com))
                print("rating"+String(self.rating))
                if(self.comment.count<1){
                    self.star = 5
                }
                
                self.avgstarview.rating = self.star
                print("star")
                print(self.star)
                
                self.cosmolist.append(self.rating1)
                self.cosmolist.append(self.com2)
                self.cosmolist.append(self.rating3)
                self.cosmolist.append(self.rating4)
                self.cosmolist.append(self.rating5)
                self.cosmolist.append(self.rating6)
                self.cosmolist.append(self.rating7)
                self.cosmolist.append(self.rating8)
                
                self.comlist.append(self.comView)
                self.comlist.append(self.comView2)
                self.comlist.append(self.comView3)
                self.comlist.append(self.comView4)
                self.comlist.append(self.comView5)
                self.comlist.append(self.comView6)
                self.comlist.append(self.comView7)
                self.comlist.append(self.comView8)
                var i=0
                for a in self.commentlist{
                    self.comlist[i].text=a
                    i = i+1
                }
                i=0
                for a in self.ratinglist{
                    print("yes")
                    print(a)
                    self.cosmolist[i].rating=a
                    self.viewlist[i].isHidden = false
                    self.h=self.h+120
                    i = i+1
                }
                
            }else{
                print("null")
            }
        }
        
        
        
        
    }
    
    
    @IBOutlet weak var menuBtn: UISegmentedControl!
    @IBAction func menu(_ sender: Any) {
        if (menuBtn.selectedSegmentIndex==0){
            self.performSegue(withIdentifier: "toHome", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==1){
            if(self.userID==0){
                self.performSegue(withIdentifier: "toLogIn", sender:sender)
            }else{
                self.performSegue(withIdentifier: "toProfile", sender: sender)
            }
        }else if (menuBtn.selectedSegmentIndex==2){
            if(self.userID==0){
                self.performSegue(withIdentifier: "toLogIn", sender:sender)
            }else{
                self.performSegue(withIdentifier: "toWish", sender: sender)
            }
        }else if (menuBtn.selectedSegmentIndex==3){
            let url4 = "http://10.202.190.193:8000/db/checkifseller/"
            let dic4 = ["userID": self.userID] as [String : Int]
            Alamofire.request(url4, method: .post, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="yes"){
                    self.performSegue(withIdentifier: "toSell", sender: sender)
                }
                else{
                    print("NOT SELLER")
                    let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "please put seller info in your profile", style: .default, handler: nil)
                    alertController.addAction(OKAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                    
                }
                
            }
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "tosellerproduct") {
            let destinationVC = segue.destination as! SellerProduct
            destinationVC.sellerID=sellerID
            destinationVC.userID=self.userID
            destinationVC.phone=self.phone
           
        }else if(segue.identifier=="toHome"){
            if let destPage=segue.destination as? ProductRecommendation {
                destPage.userID1=self.userID
            }
            
        }else if(segue.identifier=="toWish"){
            if let destPage=segue.destination as? wishlist {
                destPage.userID=self.userID
            }
            
        }else if(segue.identifier=="toProfile"){
            if let destPage=segue.destination as? profile {
                destPage.uID=self.userID
            }
            
        }
        else if(segue.identifier=="toSell"){
            if(userID==0){
                self.performSegue(withIdentifier: "toLogIn", sender: sender)
                return
            }
                
            else{
                let url3 = "http://10.202.190.193:8000/db/checkifseller/"
                let dic3 = ["userID": self.userID] as [String : Int]
                Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="yes"){
                        
                        if let destPage=segue.destination as? sell {
                            destPage.userID = self.userID
                        }
                    }
                    
                    
                }
                
                
                
            }
            
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
