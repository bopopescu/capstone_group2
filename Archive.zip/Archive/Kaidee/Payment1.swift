//
//  Payment1.swift
//  Kaidee
//
//  Created by supidsara thantanaporn on 4/6/17.
//  Copyright © 2017 Group2. All rights reserved.
//

import UIKit

class Payment1: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    var pid:Int!
    var uid:Int!
    var bankname: String!
    var bankid: Int!
    var strDate:String!
    var date:Date!
    var amount:Int!

    @IBOutlet weak var ok: UIButton!
    
    @IBAction func okB(_ sender: Any) {
        if(strDate == nil){
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "please select a date", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }else if(Int(money.text!)==nil){
            let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "invalid amount", style: .default, handler: nil)
            alertController.addAction(OKAction)
            self.present(alertController, animated: true, completion: nil)
        }else{
            self.performSegue(withIdentifier: "topayment2", sender: sender)
        }
        
        
    }
    
    @IBOutlet weak var selectedDate: UILabel!
    @IBOutlet weak var myDatePicker: UIDatePicker!

    
    @IBAction func backtocart(_ sender: Any) {
    self.dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var PickBank: UIPickerView!
    
    @IBAction func myDatePickerAction(_ sender: Any) {
        var dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        strDate = dateFormatter.string(from: myDatePicker.date)
        date = myDatePicker.date
        self.selectedDate.text = strDate
        print(date)
        print(strDate)
        
    }
    var Array = ["ธนาคารกรุงเทพ","ธนาคารกรุงไทย","ธนาคารกสิกรไทย","ธนาคารกรุงศรีอยุธยา"]

    @IBOutlet weak var money: UITextField!
    @IBAction func moneyF(_ sender: Any) {
       
        amount = Int(money.text!)

        
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
       
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    @IBOutlet weak var pickbank: UIPickerView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        PickBank.delegate = self
        PickBank.dataSource = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        bankid = row;
        //       กรุงเทพ
        if(row == 0)
        {
//            self.view.backgroundColor = UIColor.white;
            bankname = "Bangkok Bank"
        }
            
        else if(row == 1) //       กรุงไทย
        {
//            self.view.backgroundColor = UIColor.red;
            bankname = "Krungthai Bank"
        }
        else if(row == 2) //       กสิกร
        {
//            self.view.backgroundColor =  UIColor.green;
            bankname = "Kasikorn Bank"
        }
        else //       กรุงศรี
        {
//            self.view.backgroundColor = UIColor.blue;
            bankname = "Krungsri Bank"
        }
    }

    
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Array[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Array.count
    }
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "topayment2") {
            let destinationVC = segue.destination as! payment2
            destinationVC.bankid=bankid
            destinationVC.bankname=bankname
            destinationVC.strDate=strDate
            destinationVC.date=date
            destinationVC.amount=Int(money.text!)
            destinationVC.pid=self.pid
            destinationVC.uid=self.uid
            print(money.text!)
            print("bank send")
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
