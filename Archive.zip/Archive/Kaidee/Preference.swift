//
//  Preference.swift
//  Kaidee
//
//  Created by Vicky on 4/6/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class Preference: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var Picker: UIPickerView!
    @IBOutlet weak var Picker1: UIPickerView!
    
    var Array = ["มือถือ","คอมพิวเตอร์","เครื่องดนตรี","กีฬา","จักรยาน","แม่และเด็ก","กระเป๋า","นาฬิกา","รองเท้า","เสื้อผ้าและเครื่องแต่งกาย","สุขภาพและความงาม","บ้านและสวน","พระเครื่อง","ของสะสม","กล้อง","เครื่องใช้ไฟฟ้า","เกมส๋","สัตว์เลี้ยง","อสังหาริมทรัพย์","รถมือสอง","อะไหล่รถ","มอเตอร์ไซค์","งานอดิเรก","ธุรกิจ","บริการ","ท่องเที่ยว","การศึกษา","แบ่งปัน"]
    
    var Array1 = ["First Hand", "Second Hand"]
    var valueSelected=0
    var valueSelected1=1
    var phoneNum1: String!
    var arrRes = [[String:AnyObject]]()
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //comment
        Picker.delegate = self
        Picker.dataSource = self
        Picker1.delegate = self
        Picker1.dataSource = self
        
        print(phoneNum1)
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == Picker{
            return Array[row]
        }
        else{
            return Array1[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == Picker{
            return Array.count
        }
        else{
            return Array1.count
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == Picker{
            valueSelected = row
            print(valueSelected)
        }
        else{
            valueSelected1 = row
            print(valueSelected1)
        }
        
    }
    @IBAction func goToHome1(_ sender: UIButton) {
        let url = "http://10.202.190.193:8000/db/addpref/"
        var lfh :Bool!
        if(valueSelected1)==1{
            lfh=true
        }else{
            lfh=false
        }
        let dic = ["phoneNum": phoneNum1,"catID":valueSelected,"likeFirstHand" :lfh] as [String : Any]
        NSLog("%@", dic);
        
        do {
            (Alamofire.request(url, method: .post, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                response in print(response.result.value ?? "cannot print")
                
            })
            
        }
        self.performSegue(withIdentifier: "prefToHome", sender: sender)
    }
 
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
        if segue.identifier == "prefToHome" {
            let url = "http://10.202.190.193:8000/db/getuid/"
            let dic1 = ["phoneNum": phoneNum1] as [String : String]
            
            Alamofire.request(url,method: .post, parameters: dic1, encoding: JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["user2"].arrayObject {
                        
                        self.arrRes = resData as! [[String:AnyObject]]
                        
                        NSLog("%@", resData);
                    }
                    if self.arrRes.count > 0 {
                        if let destPage=segue.destination as? ProductRecommendation {
                            let x=self.arrRes[0]
                            print(x["userID"] as! Int)
                                destPage.userID1 = x["userID"] as!Int
                            
                            print(destPage.userID1)
                           
                            
                            
                        }
           
                        }
                     }
                   }
        }
     }

  
    }

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
 
