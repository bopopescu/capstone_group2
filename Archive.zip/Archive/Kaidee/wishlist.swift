//
//  wishlist.swift
//  try
//
//  Created by Admin on 4/7/2560 BE.
//  Copyright © 2560 Admin. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage
import Cosmos

class wishlist: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UIPickerViewDelegate,UITextViewDelegate , MyCollectionViewCellDelegate{
    var userID : Int!
  
    @IBOutlet weak var myCollectionView: UICollectionView!

    var images = [UIImage]()
    var priceList=[String]()
    var cate=[String]()
    var s=[String]()
    var firstTime=true
    var wishListIDList=[Int]()
    var len=0
    var checkCount = 0
    var checkReload=0
    var byCat=true
    var productToCart : Int!
    var priceToSend : Double!
    var imageToSend : UIImage!
    var cat=["มือถือ","คอมพิวเตอร์","เครื่องดนตรี","กีฬา","จักรยาน","แม่และเด็ก","กระเป๋า","นาฬิกา","รองเท้า","เสื้อผ้าและเครื่องแต่งกาย","สุขภาพและความงาม","บ้านและสวน","พระเครื่อง","ของสะสม","กล้อง","เครื่องใช้ไฟฟ้า","เกมส๋","สัตว์เลี้ยง","อสังหาริมทรัพย์","รถมือสอง","อะไหล่รถ","มอเตอร์ไซค์","งานอดิเรก","ธุรกิจ","บริการ","ท่องเที่ยว","การศึกษา","แบ่งปัน"]
    
    
    @IBOutlet weak var orderbtn: UISegmentedControl!
    @IBAction func onOrderBy(_ sender: UISegmentedControl) {
        if(orderbtn.selectedSegmentIndex==1){
            print("press order by price")
            self.orderByPrice()
            self.byCat=false
            
        }else if(orderbtn.selectedSegmentIndex==0){
            print("press order by category")
            self.orderByCat()
            self.byCat=true
        }

        
    }
    
    
  
   

      override func viewDidLoad() {
        super.viewDidLoad()
        self.myCollectionView.delegate=self
        self.myCollectionView.dataSource=self
       


        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated:Bool){
        self.orderByCat()
        print("first order by cat")
        
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count //นับว่ามีกี่รูป จะได้สร้างช่องตามรูป
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection_cell", for: indexPath) as! MyCollectionViewCell
       
           print("startsetuppage")
            cell.delegate = self
            cell.myImageView.image = self.images[indexPath.row]
            cell.c.text = "Category: "+self.cate[indexPath.row]
            cell.p.text = "Price: "+self.priceList[indexPath.row]
            cell.status.text = "Status: "+self.s[indexPath.row]
            cell.indexPath = indexPath;
        cell.productID=self.wishListIDList[indexPath.row]
        cell.price=Double(self.priceList[indexPath.row])
        cell.buyerID=self.userID
   
        checkReload=checkReload+1
        
        // does not wait. But the code in notify() is run after enter() and leave() calls are balanced
        if(checkReload==self.len){
            print("removeall")
            self.images.removeAll()
            
            self.cate.removeAll()
      
            self.priceList.removeAll()
         
            self.s.removeAll()
            print(self.s.count)
           
            self.wishListIDList.removeAll()
            
            checkCount=0
            checkReload=0
        }
     
        
        
     //   cell.id = 29; เผื่อแยก cell จากไอดี ตอนนี้แยกจากอินเด็กอยู่ (อยู่ช่องที่เท่าไหร่)
        //ค่า c,p,status ดูจาก mycollectionViewcell naa
 
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.row)
        
    }
    
    func orderByPrice(){
        //getwishlistidorderbyprice
      
        var arrRes = [Int]()
        var countA=0
        print("enterorderbyprice")
        Alamofire.request("http://10.202.190.193:8000/db/getorderedwishlist/",method: .post, parameters: ["userID":self.userID,"orderBy":"price"],encoding : JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["OrderedWishList"].arrayObject {
                    arrRes = resData[0] as! [Int]
                    if arrRes.count>0{
                        self.len=arrRes.count
                        while(countA<arrRes.count){
                            print("orderedID")
                            print(arrRes[countA])
                            
                            self.wishListIDList.append(arrRes[countA])
                            self.priceList.append("1")
                            self.images.append(UIImage(named: "2")!)
                            self.cate.append("1")
                            self.s.append("1")
                            print("countAforpic")
                            print(countA)
                            self.getProductByID(productID: self.wishListIDList[countA], countN: countA)
    
                            print("countAforinfo")
                            print(countA)
                            self.getProductInfo(productID: self.wishListIDList[countA], countN: countA)
                                

                            //                            print("do this first")
                            countA=countA+1
                            
                        }
                        
                    
                    }
                }
                
                
            }
        }
       
      
            
            ////// do your remaining work
        
      
   
    }
    func orderByCat(){
        //getwishlistidorderbycat
  
        var arrRes = [Int]()
        var countA=0
        print("enterorderbycat")
        Alamofire.request("http://10.202.190.193:8000/db/getorderedwishlist/",method: .post, parameters: ["userID":self.userID,"orderBy":"category"],encoding : JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["OrderedWishList"].arrayObject {
                    arrRes = resData[0] as! [Int]
                    if arrRes.count>0{
                        self.len=arrRes.count
                        while(countA<arrRes.count){
                            print("orderedID")
                            print(arrRes[countA])
                            
                            self.wishListIDList.append(arrRes[countA])
                            self.priceList.append("1")
                            self.images.append(UIImage(named: "2")!)
                            self.cate.append("1")
                            self.s.append("1")
                            print("countAforpic")
                            print(countA)
                            self.getProductByID(productID: self.wishListIDList[countA], countN: countA)
                            
                            print("countAforinfo")
                            print(countA)
                            self.getProductInfo(productID: self.wishListIDList[countA], countN: countA)
                            
                            
                            //                            print("do this first")
                            countA=countA+1
                            
                        }
                        
                        
                    }
                }
                
                
            }
        }
    
            
            ////// do your remaining work
        
      
        
    }
    func getProductByID(productID : Int, countN:Int){
        
        
                    print("entergetproductbyid")
                    let dict = ["productID":productID] as [String : Int]
                    Alamofire.request("http://10.202.190.193:8000/db/getpicbyproductid/", method: .post,parameters:dict, encoding: JSONEncoding.default,headers:nil).responseImage { response in
                        guard let image = response.result.value else {
                            NSLog("%@", "error");
                            return
                        }
                        print("count for pic")
                        print(countN)
                        print("arraylength")
                        print(self.images.count)
                        self.images[countN]=image
                        self.checkCount=self.checkCount+1
                        if(self.checkCount==self.len*2){
                            self.myCollectionView.reloadData()
                            print("reloadData")
                        
                    }
        
  
        
        }
    
            
        }


    func getProductInfo(productID:Int, countN:Int){
        let url2 = "http://10.202.190.193:8000/db/getproductinfo/"
        let dic2 = ["productID":productID]  as [String : Int]
        print("entergetproductinfo")
        
        Alamofire.request(url2,method: .post, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
            
                let swiftyJsonVar2 = JSON(responseData.result.value!)
                print(swiftyJsonVar2)
                
                let totalPrice=swiftyJsonVar2["deliveryFee"].doubleValue+swiftyJsonVar2["price"].doubleValue
                print("count for info")
                print(countN)
                print("check length")
                print(self.priceList.count)
                self.priceList[countN]="\(totalPrice)"
                
                if(swiftyJsonVar2["secondHandStatus"].boolValue){
                    self.s[countN]="Second-hand"
                }else{
                    self.s[countN]="First-hand"
                }
                self.cate[countN]=self.cat[swiftyJsonVar2["catID"].intValue]
                self.checkCount=self.checkCount+1
                if(self.checkCount==self.len*2){
                    self.myCollectionView.reloadData()
                    print("reloadData")
                }
            }
            
           
        }
    }
    
    @IBOutlet weak var menuBtn: UISegmentedControl!
    @IBAction func menu(_ sender: Any) {
        if (menuBtn.selectedSegmentIndex==0){
            self.performSegue(withIdentifier: "wishListToHome", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==1){
            self.performSegue(withIdentifier: "wishListToProfile", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==2){
             return
        }else if (menuBtn.selectedSegmentIndex==3){
            let url4 = "http://10.202.190.193:8000/db/checkifseller/"
            let dic4 = ["userID": self.userID] as [String : Int]
            Alamofire.request(url4, method: .post, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="yes"){
                    self.performSegue(withIdentifier: "wishListToSell", sender: sender)
                }
                else{
                    print("NOT SELLER")
                    let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "please put seller info in your profile", style: .default, handler: nil)
                    alertController.addAction(OKAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                    
                }
                
            }
        }
    }
    


    func add2Cart(productID : Int,price : Double,image: UIImage){
        print("gettoadd2cartmethod")
        self.productToCart=productID
        self.priceToSend=price
        self.imageToSend=image
        
        self.performSegue(withIdentifier: "wishListToCart", sender: nil)
      
    }
    func removeFromWish(){
        //
        if(byCat){
            self.orderByCat()
        }else{
            self.orderByPrice()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier=="wishListToHome"){
            if let destPage=segue.destination as? ProductRecommendation {
                destPage.userID1=self.userID
            }
            
        }else if(segue.identifier=="wishListToProfile"){
            if let destPage=segue.destination as? profile {
                destPage.uID=self.userID
            }
            
        }else if(segue.identifier=="wishListToCart"){
            print("preparetocart")
            if let destPage=segue.destination as? Cart {
                destPage.userID=self.userID
                destPage.productToAddID=self.productToCart
                destPage.pricestr=String(self.priceToSend)
                destPage.image=self.imageToSend
            }
            
        }else if(segue.identifier=="wishListToSell"){
                let url3 = "http://10.202.190.193:8000/db/checkifseller/"
                let dic3 = ["userID": self.userID] as [String : Int]
                Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="yes"){
                        
                        if let destPage=segue.destination as? sell {
                            destPage.userID = self.userID
                        }
                    }
                    
                    
            }
    
            
        }
        
        
        
    }

    
    }





    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


