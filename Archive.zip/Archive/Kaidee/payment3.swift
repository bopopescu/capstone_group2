//
//  payment3.swift
//  Kaidee
//
//  Created by supidsara thantanaporn on 4/7/17.
//  Copyright © 2017 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage

class payment3: UIViewController {
    var bankname: String!
    var bankid: Int!
    var sendImage: UIImage!
    var strDate: String!
    var date: Date!
    var amount:Int!
    var userid: Int!
    var productid : Int!
    var localPath:URL!
    var dic:[String:String]!
   
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    @IBAction func back2(_ sender: Any) {
       self.dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var imageView: UIImageView!
   
    @IBOutlet weak var bankLabel: UILabel!
    @IBAction func confirmbtn(_ sender: Any) {
        self.performSegue(withIdentifier: "confirmtoprofile", sender: sender)
    }
   
    
    func imageWithImage(sourceImage:UIImage,scaledToWidth: CGFloat) -> UIImage{
        let oldWidth = sourceImage.size.width
        let scaleFactor = scaledToWidth/oldWidth
        
        let newHeight = sourceImage.size.height*scaleFactor
        let newWidth = oldWidth*scaleFactor
        
        UIGraphicsBeginImageContext(CGSize(width:newWidth, height:newHeight))
        sourceImage.draw(in: CGRect(x:0,y:0,width:newWidth,height:newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }

    
    @IBAction func confirm(_ sender: UIButton) {
        sendImage = imageWithImage(sourceImage:sendImage,scaledToWidth:300)

        let imageName = "temp.jpg"
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let imagePath = documentsDirectoryURL.appendingPathComponent(imageName)
        
        // Set static name, so everytime image is cloned, it will be named "temp", thus rewrite the last "temp" image.
        // *Don't worry it won't be shown in Photos app.
        
        
        // Encode this image into JPEG. *You can add conditional based on filetype, to encode into JPEG or PNG
        if let data = UIImageJPEGRepresentation(sendImage, 80) {
            // Save cloned image into document directory
            do{
                try(data.write(to: imagePath))
                
            }catch{
                print(Error.self)
            }
            
            localPath = imagePath
            let url = "http://10.202.190.193:8000/db/addpayment/"+String(userid)+"/"
            
            Alamofire.upload(multipartFormData: { MultipartFormData in
                // get file path URL
                let filePath = self.localPath
                // add file as Request Body with fieldname "upload"
                MultipartFormData.append(filePath!, withName: "upload")
                //     MultipartFormData.append("Alamofire".data(using:String.Encoding.utf8, allowLossyConversion: false)!,withName:"test")
                let dict = self.dic as! [String:String]
                
                
                for(key,value) in dict{
                    if JSONSerialization.isValidJSONObject(value) {
                        let array = value as! [String]
                        
                        for string in array {
                            if let stringData = string.data(using: .utf8) {
                                MultipartFormData.append(stringData, withName: key+"[]")
                            }
                        }
                        
                    } else {
                        MultipartFormData.append(String(describing: value).data(using: .utf8)!, withName: key)
                    }
                }
                
                
                //                for(key,value) in dict{
                //                    print(key)
                //                    print(value)
                //                    MultipartFormData.append(value.data(using: .utf8)!, withName: key)
                //                }
                
                
            }, to: url, method: .post, headers: nil, encodingCompletion: {
                encodingResult in
                print(encodingResult)
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.response { [weak self] response in
                        guard let strongSelf = self else {
                            return
                        }
                        print("response")
                        let d=JSON(response.data)
                        print(d)
                        //                        var k = d["id"].int!
                        //                        print(k)
                        //                        self!.productid = k
                        
                    }
                case .failure(let error):
                    print(error)
                }
            })
            
        }
        print("uploaded")
        self.performSegue(withIdentifier: "confirmtoprofile", sender: sender)
        

    }
  
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = sendImage
        print("payment3")
        print(bankid)
        print(bankname)
        print(amount)
        bankLabel.text = bankname
        dateLabel.text = strDate
        moneyLabel.text = String(amount)
        dic = ["bankid":String(bankid),"amount":String(amount) ,"date":strDate,"pid":String(productid)]
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "confirmtoprofile") {
            let destinationVC = segue.destination as! profile
            destinationVC.uID=self.userid
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
