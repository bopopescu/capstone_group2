//
//  profile.swift
//  try
//
//  Created by Admin on 4/6/2560 BE.
//  Copyright © 2560 Admin. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import AlamofireImage

class profile: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    var order1=" "
    var uID : Int!
    @IBOutlet weak var myImage: UIImageView!

    @IBOutlet weak var phoneNum: UILabel!
    @IBOutlet weak var userID: UILabel!
    @IBOutlet weak var tblJSON: UITableView!
    var arrRes = [[String:AnyObject]]()
    
    @IBAction func editPIC(_ sender: Any) {
        let image = UIImagePickerController()
        image.delegate=self
        
        
        let refreshAlert = UIAlertController(title: "Photo Access", message: "Choose photo source", preferredStyle: .actionSheet)
        
        refreshAlert.addAction(UIAlertAction(title: "camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                image.sourceType = UIImagePickerControllerSourceType.camera
                image.allowsEditing = false
                self.present(image,animated:true)
            }else{ }
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "album", style: .default, handler: { (action: UIAlertAction) in
            image.sourceType = UIImagePickerControllerSourceType.photoLibrary
            image.allowsEditing = false
            self.present(image,animated:true,completion: nil)
        }))
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(refreshAlert,animated:true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            myImage.image=image
        }else{
            //error msg
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion:nil )
    }
    

    
    @IBOutlet weak var con1: UIButton!
    
    @IBOutlet weak var con2: UIButton!
    
    @IBOutlet weak var con6: UIButton!
    @IBOutlet weak var con5: UIButton!
    @IBOutlet weak var con4: UIButton!
    @IBOutlet weak var con3: UIButton!
    
    @IBOutlet weak var or1: UILabel!
    @IBOutlet weak var or2: UILabel!
    @IBOutlet weak var or3: UILabel!
    @IBOutlet weak var or4: UILabel!
    @IBOutlet weak var or5: UILabel!
    @IBOutlet weak var or6: UILabel!
    
    override func viewDidAppear(_ animated: Bool) {
        
        con1.layer.cornerRadius=5
        con2.layer.cornerRadius=5
        con3.layer.cornerRadius=5
        con4.layer.cornerRadius=5
        con5.layer.cornerRadius=5
        con6.layer.cornerRadius=5
        
        
        let userID = String(self.userID.text!)
        let url = "http://10.202.190.193:8000/db/Kaidee/Order/"
        
        let dic = ["userID": uID]
        
        
        
        NSLog("%@", dic);
        do {
            (Alamofire.request(url, method: .post, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseJSON {(responseData) -> Void in
                //                print(response.result.value!)
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["orderID"].arrayObject {
                        
                        self.arrRes = resData as! [[String:AnyObject]]
                        
                        NSLog("%@", resData);
                    }
                    
                    self.con1.isHidden = true
                    self.con2.isHidden = true
                    self.con3.isHidden = true
                    self.con4.isHidden = true
                    self.con5.isHidden = true
                    self.con6.isHidden = true
                    
                    self.or1.isHidden = true
                    self.or2.isHidden = true
                    self.or3.isHidden = true
                    self.or4.isHidden = true
                    self.or5.isHidden = true
                    self.or6.isHidden = true
                    
                    var count = 0
                    if self.arrRes.count > 0 {
                        for m in self.arrRes {
                            var dict = m
                            var x : (String)
                            x = (dict["orderID"] as? String)!
                            count = count+1
                            if(count == 1) {
                                self.or1.text = x
                                self.or1.isHidden = false
                                self.con1.isHidden = false
                            } else if (count == 2) {
                                self.or2.text = x
                                self.or2.isHidden = false
                                self.con2.isHidden=false
                            } else if (count == 3) {
                                self.or3.text = x
                                self.or3.isHidden = false
                                self.con3.isHidden=false
                            } else if (count == 4) {
                                self.or4.text = x
                                self.or4.isHidden = false
                                self.con4.isHidden=false
                            } else if (count == 5) {
                                self.or5.text = x
                                self.or5.isHidden = false
                                self.con5.isHidden=false
                            } else if (count == 6) {
                                self.or6.text = x
                                self.or6.isHidden = false
                                self.con6.isHidden=false
                            }
                            print("Hello")
                        }
                    }
                }
                }
            )}
        
        
        let url2 = "http://10.202.190.193:8000/db/Kaidee/profile/"
        let dic2 = ["userID": uID]
        NSLog("%@", dic);
        do {
            (Alamofire.request(url2, method: .post, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseJSON {(responseData) -> Void in
                //                print(response.result.value!)
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["profile"].arrayObject {
                        
                        self.arrRes = resData as! [[String:AnyObject]]
                        
                        NSLog("%@", resData);
                    }
                    if self.arrRes.count > 0 {
                        for m in self.arrRes {
                            var dict = m
                            var x : (String)
                            x = (dict["userID"] as? String)!
                            self.userID.text = x
                            
                            x = (dict["phoneNumber"] as? String)!
                            self.phoneNum.text = x
                        }
                        
                    }
                    
                    
                }
                }
            )
        }
        print("success")
        
        
        
        // Do any additional setup after loading the view.
    }

    
    @IBAction func confirm1(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Confirm order", message: "This will lead to comment and rating for product delivery", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            self.con1.tag = 1
            
            
            let url = "http://10.202.190.193:8000/db/Kaidee/status/"
            let dic = ["orderID": self.or1.text]
            
            NSLog("%@", dic);
            do {
                (Alamofire.request(url, method: .put, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                        
                    }
                    
                })
                
                
                
                
            }
            (self.performSegue(withIdentifier: "toComment", sender: sender))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        
    }
    
    @IBAction func confirm2(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Confirm order", message: "This will lead to comment and rating for product delivery", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            self.con2.tag = 1
            let url = "http://10.202.190.193:8000/db/Kaidee/status/"
            let dic2 = ["orderID": self.or2.text]
            NSLog("%@", dic2);
            do {
                (Alamofire.request(url, method: .put, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                    }
                    
                })
                
                
                
                
            }
            
            (self.performSegue(withIdentifier: "toComment", sender: sender))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        
    }
    @IBAction func confirm3(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Confirm order", message: "This will lead to comment and rating for product delivery", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            self.con3.tag = 1
            let url = "http://10.202.190.193:8000/db/Kaidee/status/"
            let dic3 = ["orderID": self.or3.text]
            NSLog("%@", dic3);
            do {
                (Alamofire.request(url, method: .put, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                    }
                    
                })
                
                
                
                
            }
            (self.performSegue(withIdentifier: "toComment", sender: sender))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        
    }
    @IBAction func confirm4(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Confirm order", message: "This will lead to comment and rating for product delivery", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            self.con4.tag = 1
            let url = "http://10.202.190.193:8000/db/Kaidee/status/"
            let dic4 = ["orderID": self.or4.text]
            NSLog("%@", dic4);
            do {
                (Alamofire.request(url, method: .put, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                    }
                    
                })
            }
            (self.performSegue(withIdentifier: "toComment", sender: sender))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        
    }
    @IBAction func confirm5(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Confirm order", message: "This will lead to comment and rating for product delivery", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            self.con5.tag = 1
            let url = "http://10.202.190.193:8000/db/Kaidee/status/"
            let dic5 = ["orderID": self.or5.text]
            NSLog("%@", dic5);
            do {
                (Alamofire.request(url, method: .put, parameters: dic5, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                    }
                    
                })
            }
            (self.performSegue(withIdentifier: "toComment", sender: sender))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        
    }
    @IBAction func confirm6(_ sender: UIButton) {
        let refreshAlert = UIAlertController(title: "Confirm order", message: "This will lead to comment and rating of product delivery", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            
            self.con6.tag = 1
            let url = "http://10.202.190.193:8000/db/Kaidee/status/"
            let dic6 = ["orderID": self.or6.text]
            NSLog("%@", dic6);
            do {
                (Alamofire.request(url, method: .put, parameters: dic6, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                    }else{
                        print("NOOOOOOO")
                    }
                    
                })
            }
            (self.performSegue(withIdentifier: "toComment", sender: sender))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
            print("Handle Cancel Logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (con1.tag == 1) {
            order1 = String(or1.text!)
        }   else if (con2.tag == 1) {
            order1 = String(or2.text!)
        }   else if (con3.tag == 1) {
            order1 = String(or3.text!)
        }   else if (con4.tag == 1) {
            order1 = String(or4.text!)
        }   else if (con5.tag == 1) {
            order1 = String(or5.text!)
        }   else if (con6.tag == 1) {
            order1 = String(or6.text!)
        }
        if segue.identifier == "toComment" {
            if let destinationP = segue.destination as? comment {
                destinationP.test = order1
                destinationP.userID=self.uID
            }
        }
        if segue.identifier == "toSetting" {
            if let destinationP = segue.destination as? setting {
                destinationP.uID = self.uID
            }
        }
        if segue.identifier == "toHome" {
            if let destinationP = segue.destination as? ProductRecommendation{
                destinationP.userID1 = self.uID
            }
        }
        if segue.identifier == "toWish" {
            if let destinationP = segue.destination as? wishlist {
                destinationP.userID = self.uID
            }
        }
        if segue.identifier == "toSell" {
            let url3 = "http://10.202.190.193:8000/db/checkifseller/"
            let dic3 = ["userID": self.uID] as [String : Int]
            Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="yes"){
                    
                    if let destPage=segue.destination as? sell {
                        destPage.userID = self.uID
                    }
                }
                
                
            }
        }
        
    }
   
    
    @IBOutlet weak var menuBtn: UISegmentedControl!
    
    @IBAction func menu(_ sender: Any) {
        if (menuBtn.selectedSegmentIndex==0){
            self.performSegue(withIdentifier: "toHome", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==1){
        //    self.performSegue(withIdentifier: "toProfile", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==2){
            self.performSegue(withIdentifier: "toWish", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==3){
            let url4 = "http://10.202.190.193:8000/db/checkifseller/"
            let dic4 = ["userID": self.uID] as [String : Int]
            Alamofire.request(url4, method: .post, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="yes"){
                    self.performSegue(withIdentifier: "toSell", sender: sender)
                }
                else{
                    print("NOT SELLER")
                    let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                    let OKAction = UIAlertAction(title: "please put seller info in your profile", style: .default, handler: nil)
                    alertController.addAction(OKAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                    
                }
                
            }
        }
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */


}
