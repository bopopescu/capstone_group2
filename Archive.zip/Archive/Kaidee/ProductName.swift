//
//  ProductName.swift
//  Kaidee
//
//  Created by supidsara thantanaporn on 4/6/17.
//  Copyright © 2017 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ProductName: UIViewController {
    var productID :Int!
    var userID: Int!
    var tagID: Int = -1
    var cango=true
    var price : Int!
    var imagetosend: UIImage!

    @IBOutlet weak var priceLabel: UILabel!

    @IBOutlet weak var delPriceLabel: UILabel!
    
    @IBOutlet weak var sellerIDLabel: UILabel!
    
    
    @IBOutlet weak var desLabel: UILabel!
    
    @IBOutlet weak var handStatusLabel: UILabel!
    @IBOutlet weak var productIDLabel: UILabel!
    @IBOutlet weak var productImageView: UIImageView!
    var arrRes = [Int]()
    var wishListIDList  = [Int]()
    var sID :Int!
  
    override func viewDidLoad() {
        super.viewDidLoad()
       
       
        
        
           
       
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        print(self.userID)
        print(self.productID)
        self.productIDLabel.text="PRODUCT ID:"+"\(self.productID!)"
        print("getPic")
        let dict = ["productID":self.productID] as [String : Int]
        Alamofire.request("http://10.202.190.193:8000/db/getpicbyproductid/", method: .post,parameters:dict, encoding: JSONEncoding.default,headers:nil).responseImage { response in
            guard let image = response.result.value else {
                NSLog("%@", "error");
                return
            }
            
            self.productImageView.image=image
            self.imagetosend = image
        }
        let url2 = "http://10.202.190.193:8000/db/getproductinfo/"
        let dic2 = ["productID": self.productID] as [String : Int]
        
        Alamofire.request(url2,method: .post, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                NSLog("%@", url2);
                let swiftyJsonVar2 = JSON(responseData.result.value!)
                print(swiftyJsonVar2)
            
                        self.delPriceLabel.text=swiftyJsonVar2["deliveryFee"].stringValue
                
                
                        self.sellerIDLabel.text=swiftyJsonVar2["sellerid"].stringValue
                self.sID=Int(swiftyJsonVar2["sellerid"].stringValue)
                
                        self.priceLabel.text=swiftyJsonVar2["price"].stringValue
                        self.desLabel.text=swiftyJsonVar2["des"].stringValue
                
                        if(swiftyJsonVar2["secondHandStatus"].boolValue){
                            self.handStatusLabel.text="Second-hand"
                        }else{
                            self.handStatusLabel.text="First-hand"
                        }
            
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var menuBtn: UISegmentedControl!
    @IBAction func menu(_ sender: Any) {
        if (menuBtn.selectedSegmentIndex==0){
            self.performSegue(withIdentifier: "productNameToHome", sender: sender)
        }else if (menuBtn.selectedSegmentIndex==1){
            if(self.userID==0){
                self.performSegue(withIdentifier: "productNameToLogIn", sender:sender)
            }else{
            self.performSegue(withIdentifier: "productNameToProfile", sender: sender)
            }
            
        }else if (menuBtn.selectedSegmentIndex==2){
            if(self.userID==0){
                self.performSegue(withIdentifier: "productNameToLogIn", sender:sender)
            }else{
            self.performSegue(withIdentifier: "productNameToWishList", sender: sender)
            }
            
            
        }else if (menuBtn.selectedSegmentIndex==3){
           
                let url4 = "http://10.202.190.193:8000/db/checkifseller/"
                let dic4 = ["userID": self.userID] as [String : Int]
                Alamofire.request(url4, method: .post, parameters: dic4, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="yes"){
                        self.performSegue(withIdentifier: "productNameToSell", sender: sender)
                    }
                    else{
                        print("NOT SELLER")
                        let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                        let OKAction = UIAlertAction(title: "please put seller info in your profile", style: .default, handler: nil)
                        alertController.addAction(OKAction)
                        self.present(alertController, animated: true, completion: nil)
                        
                        
                    }
                    
                }
            }
            
           
        
        
    }
    @IBAction func addToWishList(_ sender: UIButton) {
        if(self.userID==0){
            self.performSegue(withIdentifier: "productNameToLogIn", sender:sender)
        return
        }
        //check for repeat
        //check if >4
        //if success >> add to wishlist &  go to wishlist page
        var countA=0
        
        Alamofire.request("http://10.202.190.193:8000/db/getwishlistid/",method: .post, parameters: ["userID":self.userID],encoding : JSONEncoding.default, headers: nil).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
            
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["WishList"].arrayObject {
                    self.arrRes = resData[0] as! [Int]
                    if self.arrRes.count>0{
                        while(countA<self.arrRes.count){
                            print(self.arrRes[countA])
                            self.wishListIDList.append(self.arrRes[countA])
                            countA=countA+1
                        }
                        var countB=0
                        if(self.wishListIDList.count==4){
                            print("TOO MUCH")
                            self.cango=false
                            let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                            let OKAction = UIAlertAction(title: "your wishlist is full", style: .default, handler: nil)
                            alertController.addAction(OKAction)
                            self.present(alertController, animated: true, completion: nil)
                            return
                        }
                        while(countB<self.wishListIDList.count){
                            
                            if(self.wishListIDList[countB]==self.productID){
                                self.cango=false
                                let alertController = UIAlertController(title: self.title, message: nil, preferredStyle: .alert)
                                let OKAction = UIAlertAction(title: "This is already in your wishlist", style: .default, handler: nil)
                                alertController.addAction(OKAction)
                                self.present(alertController, animated: true, completion: nil)
                                return
                            }
                            countB=countB+1
                        }
                        
                    }
                }
            }
            
            if(self.cango){let url = "http://10.202.190.193:8000/db/addtowishlist/"
            
            let dic = ["productID": self.productID,"userID":self.userID]
            NSLog("%@", dic);
            do {
                (Alamofire.request(url, method: .post, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                        self.performSegue(withIdentifier: "productNameToWishList", sender: sender)
                    }else{
                        print("NOT SUCCESS")
                    }
                    
                })
            }
        }
        
        }
        
    }
    @IBAction func addToCart(_ sender: UIButton) {
        if(self.userID==0){
            self.performSegue(withIdentifier: "productNameToLogIn", sender:sender)
        return
        }
        
        //set ifActive to false, remove from wishlist of everyone
        do {
            (Alamofire.request("http://10.202.190.193:8000/db/removefromwishlist/", method: .post, parameters: ["productID": productID], encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="success"){
                    print("SUCCESSSSSS")
                }
            })
        }
        do {
            (Alamofire.request("http://10.202.190.193:8000/db/setisactivefalse/", method: .post, parameters: ["productID": productID], encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="success"){
                    print("SUCCESSSSSS")
                }
            })
        }
        
        self.performSegue(withIdentifier: "productNameToCart", sender: sender)
        
       
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier=="productNameToHome"){
            if let destPage=segue.destination as? ProductRecommendation {
                        destPage.userID1=self.userID
            }
            
        }else if(segue.identifier=="productNameToWishList"){
            if let destPage=segue.destination as? wishlist {
                destPage.userID=self.userID
            }
            
        }else if(segue.identifier=="productNameToProfile"){
            if let destPage=segue.destination as? profile {
                destPage.uID=self.userID
            }
            
        }
        else if(segue.identifier=="toSellerProfile"){
            if let destPage=segue.destination as? sellerProfile {
                destPage.userID=self.userID
                destPage.sellerID=self.sID
            }
            
        }else if(segue.identifier=="productNameToSell"){
            if(userID==0){
                self.performSegue(withIdentifier: "productNameToLogIn", sender: sender)
                return
            }
                
            else{
                let url3 = "http://10.202.190.193:8000/db/checkifseller/"
                let dic3 = ["userID": self.userID] as [String : Int]
                Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="yes"){
                        
                        if let destPage=segue.destination as? sell {
                            destPage.userID = self.userID
                        }
                    }
                    
                    
                }
                
                
                
            }

            
        }else if(segue.identifier=="productNameToSellerProfile"){
            if let destPage=segue.destination as? sellerProfile {
                destPage.userID=self.userID
            }
            
        }else if(segue.identifier=="productNameToCart"){
            if(userID==0){
                self.performSegue(withIdentifier: "productNameToLogIn", sender: sender)
            }
            if let destPage=segue.destination as? Cart {
                destPage.userID=self.userID
                destPage.productToAddID=self.productID
                destPage.image=self.imagetosend
                destPage.pricestr=self.priceLabel.text
                destPage.price=Int(self.priceLabel.text!)
            }
            
        }
        

        
    }

    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
