//
//  editEmail.swift
//  Kaidee
//
//  Created by Admin on 4/6/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//
import UIKit
import Alamofire
import SwiftyJSON

class editEmail: UIViewController,UITextFieldDelegate {
    var sID : Int!
    var arrRes = [[String:AnyObject]]()
    var boolean1 = true
    override func viewDidLoad() {
        super.viewDidLoad()
        inputEmail.delegate=self
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet var inputEmail: UITextField!
    
    @IBAction func saveEmail(_ sender: Any) {
        let email1 = String(self.inputEmail.text!)
        let url = "http://10.202.190.193:8000/db/Kaidee/getSeller/"
        Alamofire.request(url).responseJSON { (responseData) -> Void in
            if((responseData.result.value) != nil) {
                
                NSLog("%@", url);
                
                let swiftyJsonVar = JSON(responseData.result.value!)
                if let resData = swiftyJsonVar["seller2"].arrayObject {
                    
                    self.arrRes = resData as! [[String:AnyObject]]
                    
                    NSLog("%@", resData);
                    print(self.arrRes.count)
                }
            }
            print(self.arrRes.count)
            if (self.arrRes.count) > 0 {
                print("arrRes not null")
                for a in self.arrRes{
                    var dict = a
                    print(dict)
                    print(self.sID)
                    if((dict["sellerID"]as? String)==String(self.sID)){
                        self.boolean1 = true
                        print("boolean1 true")
                        break
                    } else {
                        print("there is no this seller")
                        self.boolean1 = false}
                }
            }
            
            
            
            if (self.boolean1 == true) {
                let url = "http://10.202.190.193:8000/db/Kaidee/editEmail/"
                let dic = ["email": email1, "sellerID": String(self.sID)]
                
                NSLog("%@", dic);
                do {
                    (Alamofire.request(url, method: .put, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                        response in
                        print(response.result.value!)
                        if((response.result.value!)=="success"){
                            print("SUCCESSSSSS")
                        }else{
                            print("NOOOOOOO")
                        }
                        
                    })
                    
                }
                
            }
            if self.boolean1 == false {
                let urlC = "http://10.202.190.193:8000/db/Kaidee/createSeller/"
                let dicC = ["email": email1, "sellerID": String(self.sID), "bank": "null"]
                NSLog("%@", dicC);
                do {
                    (Alamofire.request(urlC, method: .post, parameters: dicC, encoding: JSONEncoding.default, headers: nil).responseString {
                        response in
                        print(response.result.value!)
                        if((response.result.value!)=="success"){
                            print("SUCCESSSSSS")
                        }else{
                            print("NOOOOOOO")
                        }
                        
                    })
                    
                }

                
            }
        }
    }
    
    @IBAction func onBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }

    
    
    /*
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
