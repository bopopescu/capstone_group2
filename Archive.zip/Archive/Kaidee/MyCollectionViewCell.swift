//
//  MyCollectionViewCell.swift
//  try
//
//  Created by Admin on 4/7/2560 BE.
//  Copyright © 2560 Admin. All rights reserved.
//
protocol MyCollectionViewCellDelegate: class {
    func add2Cart(productID : Int,price : Double,image :UIImage)
    func removeFromWish()
}
import UIKit
import Alamofire
import SwiftyJSON

class MyCollectionViewCell: UICollectionViewCell {
    
    var indexPath: IndexPath? = nil;
    var id: Int = 0;
    var productID:Int!
    var buyerID:Int!
    var price: Double!
    @IBOutlet weak var c: UILabel!
    @IBOutlet weak var p: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var status: UILabel!
    var count=0
     weak var delegate:MyCollectionViewCellDelegate?
    @IBAction func addToCart(_ sender: UIButton) {
        
        print("add at \(String(describing: indexPath?.row))")
        print(self.productID)
        do {
            (Alamofire.request("http://10.202.190.193:8000/db/removefromwishlist/", method: .post, parameters: ["productID": self.productID], encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="success"){
                    print("SUCCESSSSSS")
                    self.count=self.count+1
                    if(self.count==2){
                        print("add2cart")
                        if let del = self.delegate {
                            del.add2Cart(productID: self.productID,price : self.price,image:self.myImageView.image!)
                        }
                        self.count=0
                    }
                }
            })
        }
        do {
            (Alamofire.request("http://10.202.190.193:8000/db/setisactivefalse/", method: .post, parameters: ["productID": self.productID], encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="success"){
                    print("SUCCESSSSSS")
                    self.count=self.count+1
                    if(self.count==2){
                        print("add2cart")
                        if let del = self.delegate {
                            del.add2Cart(productID: self.productID,price : self.price,image:self.myImageView.image!)
                        }
                        self.count=0
                    }
                }
            })
        }
       

    }
    @IBOutlet weak var addCart: UIButton!
    
    @IBAction func removeWish(_ sender: UIButton) {
        print("remove from my wishlist", indexPath!.row)
        print(self.productID)
        //removefromwishlistbyid >> do it in pycharm
        do {
            (Alamofire.request("http://10.202.190.193:8000/db/removefrommywishlist/", method: .post, parameters: ["productID": self.productID,"buyerID":self.buyerID], encoding: JSONEncoding.default, headers: nil).responseString {
                response in
                print(response.result.value!)
                if((response.result.value!)=="success"){
                    print("SUCCESSSSSS")
                    if let del = self.delegate {
                        del.removeFromWish()
                    }
                }
            })
        }
    }
    
}
