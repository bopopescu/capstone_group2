//
//  setting.swift
//  Kaidee
//
//  Created by Admin on 4/6/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//
import UIKit
import Alamofire
import SwiftyJSON

class setting: UIViewController {
    @IBOutlet weak var tblJSON: UITableView!
    var arrRes = [[String:AnyObject]]()
    var phoneNum = " "
       // @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var bank: UILabel!
    var uID : Int!
    
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var editBankButt: UIButton!
 
    @IBAction func editPhone(_ sender: Any) {
           self.performSegue(withIdentifier: "editPhone", sender: sender)
    }
    @IBAction func editBank(_ sender: Any) {
          self.performSegue(withIdentifier: "toEditBank", sender: sender)
    }
    override func viewDidAppear(_ animated: Bool) {
        
        email.layer.borderWidth = 0.5
        email.layer.borderColor = UIColor.black.cgColor
        email.layer.cornerRadius = 4
        bank.layer.borderWidth = 0.5
        bank.layer.borderColor = UIColor.black.cgColor
        bank.layer.cornerRadius = 4
        phone.layer.borderWidth = 0.5
        phone.layer.borderColor = UIColor.black.cgColor
        phone.layer.cornerRadius = 4
        
        let url2 = "http://10.202.190.193:8000/db/Kaidee/profile/"
        let dic2 = ["userID": uID]
        NSLog("%@", dic2);
        do {
            (Alamofire.request(url2, method: .post, parameters: dic2, encoding: JSONEncoding.default, headers: nil).responseJSON {(responseData) -> Void in
                //                print(response.result.value!)
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url2);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["profile"].arrayObject {
                        
                        self.arrRes = resData as! [[String:AnyObject]]
                        
                        NSLog("%@", resData);
                    }
                    if self.arrRes.count > 0 {
                        for m in self.arrRes {
                            var dict = m
                            var x : (String)
                            x = (dict["phoneNumber"] as? String)!
                            self.phone.text = x
                        }
                        
                    }
                    
                    
                }
                }
            )
        }
        
        let url3 = "http://10.202.190.193:8000/db/Kaidee/seller/"
        let dic3 = ["userID": uID]
        NSLog("%@", dic3);
        do {
            (Alamofire.request(url3, method: .post, parameters: dic3, encoding: JSONEncoding.default, headers: nil).responseJSON {(responseData) -> Void in
                //                print(response.result.value!)
                if((responseData.result.value) != nil) {
                    
                    NSLog("%@", url3);
                    
                    let swiftyJsonVar = JSON(responseData.result.value!)
                    if let resData = swiftyJsonVar["seller"].arrayObject {
                        
                        self.arrRes = resData as! [[String:AnyObject]]
                        
                        NSLog("%@", resData);
                    }
                    if self.arrRes.count > 0 {
                        self.editBankButt.isEnabled = true
                        for m in self.arrRes {
                            var dict = m
                            var x : (String)
                            x = (dict["email"] as? String)!
                            self.email.text = x
                            print(x)
                            x = (dict["bank"] as? String)!
                            self.bank.text = x
                            
                            
                        }
                        
                    } else {
                        self.editBankButt.isEnabled = false
                    }
                }
                }
            )
        }
        
    }
    
    // Do any additional setup after loading the view.
    

    @IBAction func toProfile(_ sender: Any) {
        self.performSegue(withIdentifier: "backToProfile", sender: sender)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        phoneNum = self.phone.text!
        if segue.identifier == "editPhone" {
            if let destinationPhone = segue.destination as? editPhone {
                destinationPhone.phone1 = phoneNum
                destinationPhone.uID = self.uID
            }
        }
        if segue.identifier == "editPass" {
            if let destinationPhone = segue.destination as? editPass {
                destinationPhone.phone1 = phoneNum
                destinationPhone.uID = self.uID
            }
        }
        if segue.identifier == "editEmail" {
            if let destinationPhone = segue.destination as? editEmail {
                destinationPhone.sID = self.uID
              
            }
        }
        if segue.identifier == "toEditBank" {
            if let destinationPhone = segue.destination as? editbankaccount {
                destinationPhone.sID = self.uID
            }
        }
        if segue.identifier == "backToProfile" {
            if let destinationPhone = segue.destination as? profile {
                destinationPhone.uID = self.uID
            }
        }
    }
    
    
    
    /*
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
