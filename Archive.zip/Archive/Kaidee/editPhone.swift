//
//  editPhone.swift
//  Kaidee
//
//  Created by Admin on 4/12/2560 BE.
//  Copyright © 2560 Group2. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON




class editPhone: UIViewController,UITextFieldDelegate {
    var phone1 : String!
    var uID:Int!

    @IBOutlet weak var OTP: UITextField!
    @IBOutlet weak var phoneNum: UITextField!
    @IBOutlet weak var hideLabel: UILabel!
    @IBAction func onBack(_ sender: Any) {
        self.performSegue(withIdentifier: "toSetting", sender: sender)
    }
    override func viewDidAppear(_ animated: Bool) {
        hideLabel.isHidden = true
        print(phone1)
        // Do any additional setup after loading the view.
    }
    override func viewDidLoad() {
       
      super.viewDidLoad()
        phoneNum.delegate=self
        OTP.delegate=self
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    @IBAction func onSave(_ sender: Any) {
        let phoneNum = String(self.phoneNum.text!)
        if (phoneNum?.characters.count)! < 10 || (phoneNum?.characters.count)!>10 {
            hideLabel.isHidden = false
        } else {
            let url = "http://10.202.190.193:8000/db/Kaidee/editPhone/"
            
            let dic = ["newNum": phoneNum, "oldNum" : phone1]
            NSLog("%@", dic);
            do {
                (Alamofire.request(url, method: .put, parameters: dic, encoding: JSONEncoding.default, headers: nil).responseString {
                    response in
                    print(response.result.value!)
                    if((response.result.value!)=="success"){
                        print("SUCCESSSSSS")
                        self.performSegue(withIdentifier:"toSetting", sender: sender)
                    }else{
                        print("NOOOOOOO")
                        self.hideLabel.text="Invalid phone number"
                    }
                    
                })
                
            }
            
            self.dismiss(animated: true, completion: nil)
        }
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
   
        if segue.identifier == "toSetting" {
            if let destinationP = segue.destination as? setting {
                destinationP.uID = self.uID
            }
        }
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
